--zad 3.8
select * from Pracownicy join Dzialy using(id_dzialu)
where nazwa like 'Produkcja' and (data_zwol is NULL
or data_zwol >= Sysdate) and (data_zatr between
to_date('01-10-2007', 'dd-mm-yyyy') and
to_date('31-03-2013','dd-mm-yyyy'));

-- zad 5.2
select * from wedkarze wed where exists(select * 
from rejestry join lowiska using (id_lowiska) 
where id_wedkarza = wed.id_wedkarza 
and id_okregu like 'PZW Czestochowa') and exists(select * 
from rejestry join lowiska using (id_lowiska) 
where id_wedkarza = wed.id_wedkarza 
and id_okregu in ('PZW Opole', 'PZW Katowice')) and not exists(select * 
from rejestry join lowiska using (id_lowiska) 
where id_wedkarza = wed.id_wedkarza 
and id_okregu not like 'PZW%') and 5<=any
(select count(*)-count(id_gatunku) 
from rejestry where id_wedkarza = wed.id_wedkarza 
group by to_char(czas, 'd'));

--zad 5.3
SELECT TO_CHAR(data_produkcji, 'ww') tydzien, COUNT(*)
FROM pojazdy
WHERE data_produkcji BETWEEN TIMESTAMP'2001-01-01 14:57:00'
AND TIMESTAMP'2016-06-12 14:57:00'
GROUP BY TO_CHAR(data_produkcji, 'ww')
HAVING COUNT(*) BETWEEN 50 AND 150;

--3.12
select * from pojazdy where typ like 'MOTOCYKL' 
and extract(year from data_produkcji)=
extract (year from sysdate-interval '10' year);

--3.6 mod

select to_date ('25-01-2021', 'dd-mm-yyyy') + interval '135-5'
year(3) to month, to_char (to_date ('25-01-2021', 'dd-mm-yyyy') + interval '135-5'
year(3) to month, 'yyyy-mm-dd day')
from dual;

-- zad 5.4
select * from wlasciciele wl 
where exists
(select * from pojazdy 
where to_number(to_char(data_produkcji,'cc'))=20 
and id_wlasciciela=wl.id_wlasciciela)
and not exists 
(select * from pojazdy 
where to_number(to_char(data_produkcji,'cc'))=21 and typ like 'MOTOCYKL' 
and id_wlasciciela=wl.id_wlasciciela) 
and 1000<= all
(select pojemnosc from pojazdy 
where id_wlasciciela=wl.id_wlasciciela)
and 3000<= any
(select pojemnosc from pojazdy 
where id_wlasciciela=wl.id_wlasciciela);

-- zad 3.9
select nazwisko from wedkarze
where length (nazwisko)>=7 
and imiona not like '%a' 
minus
select nazwisko from studenci
where length (nazwisko)>=7 
and imiona not like '%a';

-- zad 5.1
SELECT  nvl(nazwa,'brak_dzialu') nazwa , id_dzialu, count(*) from pracownicy 
left join dzialy using(id_dzialu) where data_zwol < sysdate
group by nazwa, id_dzialu having count(*) >= 2;

-- 
select nr_rejestracyjny from pojazdy 
where regexp_like(trim(nr_rejestracyjny),'[[:alpha:]].$')
and regexp_like(trim(nr_rejestracyjny),'[[:digit:]]{2}');


