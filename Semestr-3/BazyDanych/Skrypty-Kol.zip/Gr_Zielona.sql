--zad 2.5
select count(*) from pojazdy
where trim(to_char(data_produkcji,'day')) 
in('wtorek','czwartek','sobota') 
and mod(extract(year from data_produkcji),2)=1;

--zad 3.4
select stanowisko from stanowiska 
minus
select stanowisko from pracownicy where data_zwol is null; 

--zad 4.1
select nr_indeksu, nr_rejestracyjny,substr(trim(nr_rejestracyjny), -4) 
from studenci cross join pojazdy
where mod(nr_indeksu, 10000)=to_number(substr(trim(nr_rejestracyjny), -4))
and regexp_like(trim(nr_rejestracyjny), '[[:digit:]]{4}$');

--zad 4.3
select * from wedkarze wl 
where exists(select * from rejestry join lowiska using (id_lowiska)
where upper (nazwa )like 'PORAJ' and id_wedkarza=wl.id_wedkarza 
 and id_gatunku is null )and 
 exists(select * from rejestry join lowiska using (id_lowiska)
where upper (nazwa )like 'PILICA' and id_wedkarza=wl.id_wedkarza 
 and id_gatunku is null )
 and
  not  exists(select * from rejestry join lowiska using (id_lowiska)
where upper (nazwa )like 'ODRA' and id_wedkarza=wl.id_wedkarza );

-- 3.3
 select czas, case when extract(hour from czas)between 4 and 8 then 'poranny' 
 when extract(hour from czas)between 9 and 18 then 'dzienny'
 when extract(hour from czas)between 19 and 21 then 'wieczorny'
 else 'nocny' end||' szczupak' pora 
 from rejestry join gatunki using(id_gatunku) 
 where  upper(nazwa) LIKE 'SZCZUPAK';
 
 -- 4.2
 select kolor, count(*) from pojazdy where kolor not like '% %' group by kolor
 having count(*)>=100 order by 2 desc, 1;
 
 --2.3
 select (timestamp '2011-09-12 20:15:00' - timestamp '1994-04-21 09:07:00')
 year to month from dual;
 
 -- 2.4
 select to_date('01-05-2021','dd-mm-yyyy')+
 7-to_char(to_date('01-05-2021','dd-mm-yyyy'),'d')
 from dual;
 
 -- 

