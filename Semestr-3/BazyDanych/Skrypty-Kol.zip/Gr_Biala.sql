--zad 3.4
Select * from Studenci 
where kierunek like 'INFORMATYKA' 
and to_number(to_char(data_urodzenia, 'cc')) = 20
and data_urodzenia = last_day(data_urodzenia);

--zad 3.8
select systimestamp,case
when extract(hour from systimestamp) BETWEEN 6 and 10 then 'Rano'
when extract(hour from systimestamp) BETWEEN 11 and 14 then 'Poludnie'
when extract(hour from systimestamp) BETWEEN 15 and 17 then 'Popoludnie'
when extract(hour from systimestamp) BETWEEN 18 and 21 then 'Wieczor'
else 'Noc' end info
from dual;

--zad 4.4
select stanowisko from pracownicy join dzialy using (id_dzialu)
where (data_zwol is null or data_zwol >= sysdate) 
and adres like '%Czestochowa'
minus
select stanowisko from pracownicy join dzialy using (id_dzialu)
where (data_zwol is null or data_zwol >= sysdate) 
and adres not like '%Czestochowa';

--zad 4.3
select * from wedkarze we
where exists(select * from rejestry where id_wedkarza = we.id_wedkarza and
to_number(to_char(czas, 'q')) = 2) and not
exists(select * from rejestry where id_wedkarza = we.id_wedkarza and
to_number(to_char(czas, 'q')) = 4) and 2<=
(select count(distinct extract(year from czas)) from
rejestry where id_wedkarza = we.id_wedkarza);

-- zad 4.2
select * from wlasciciele wl
where wl.status_wlasciciela like 'osoba_prawna' and EXISTS
(select count (*) from pojazdy where upper(marka)='FORD' and 
id_wlasciciela = wl.id_wlasciciela group by marka
having count (*) BETWEEN 2 and 6) and not EXISTS 
(select count (*) from pojazdy where upper(typ)='AUTOBUS' and 
id_wlasciciela = wl.id_wlasciciela group by marka
having count (*) >= 3) and 10 >= all
(select extract(year from sysdate)-extract(year from data_produkcji)
from pojazdy where id_wlasciciela = wl.id_wlasciciela);

--zad 4.6
select * from pojazdy where data_produkcji is not null and 
(typ,data_rejestracji - data_produkcji) in(
select typ,min(data_rejestracji - data_produkcji)from pojazdy
where data_produkcji is not null group by typ);

--zad 4.5
select to_char(data_wystawienia, 'month') miesiac, 
decode(ocena, null, 'Brak oceny',ocena) ocena, count (*) 
from studenci join oceny using (nr_indeksu) 
where 
data_wystawienia between timestamp'2018-02-01 18:05:00' and 
timestamp'2020-04-23 20:35:00'
group by extract(month from data_wystawienia), to_char(data_wystawienia, 'month'), 
decode(ocena, null, 'Brak oceny',ocena) order by 
extract(month from data_wystawienia), 2 desc;





