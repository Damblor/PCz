--zad 2
select to_char(czas,'yyyy-mm-dd hh24:mi')czas, dlugosc, case 
when dlugosc > 
(select round(avg(dlugosc)) srednia from rejestry join gatunki using(id_gatunku) 
where upper(nazwa) like 'SZCZUPAK') then 'dluzsza' 
when dlugosc < 
(select round(avg(dlugosc)) srednia from rejestry join gatunki using(id_gatunku) 
where upper(nazwa) like 'SZCZUPAK') then 'krotsza' else 'rowna' end komentarz
from rejestry join gatunki using (id_gatunku)where upper(nazwa) like 'SZCZUPAK';


select to_char(czas,'yyyy-mm-dd hh24:mi')czas, dlugosc, case 
when dlugosc >  (select round(avg(dlugosc)) srednia from rejestry
      where id_gatunku=re.id_gatunku) then 'dluzsza' 
when dlugosc <  (select round(avg(dlugosc)) srednia from rejestry 
   where id_gatunku=re.id_gatunku) then 'krotsza'
else 'rowna' end komentarz
from rejestry re join gatunki ga on (re.id_gatunku=ga.id_gatunku) 
where upper(nazwa) like 'SZCZUPAK';

-- zad 4
select wl.id_wlasciciela,wlasciciel 
from wlasciciele wl join pojazdy po on (wl.id_wlasciciela=po.id_wlasciciela)
where typ like 'MOTOCYKL'
group by wl.id_wlasciciela,wlasciciel having count(*)=1 
INTERSECT
select wl.id_wlasciciela,wlasciciel 
from wlasciciele wl join pojazdy po on (wl.id_wlasciciela=po.id_wlasciciela)
where typ like 'SAM_OSOBOWY'
group by wl.id_wlasciciela,wlasciciel having count(*)>=1 
INTERSECT
select wl.id_wlasciciela,wlasciciel 
from wlasciciele wl join pojazdy po on (wl.id_wlasciciela=po.id_wlasciciela)
where typ like 'SAM_CIEZAROWY'
group by wl.id_wlasciciela,wlasciciel having count(*)>=2;



select t1.id_wlasciciela,wlasciciel,count(*) from
(select wl.id_wlasciciela,wlasciciel 
from wlasciciele wl join pojazdy po on (wl.id_wlasciciela=po.id_wlasciciela)
where typ like 'MOTOCYKL'
group by wl.id_wlasciciela,wlasciciel having count(*)=1 
INTERSECT
select wl.id_wlasciciela,wlasciciel 
from wlasciciele wl join pojazdy po on (wl.id_wlasciciela=po.id_wlasciciela)
where typ like 'SAM_OSOBOWY'
group by wl.id_wlasciciela,wlasciciel having count(*)>=1 
INTERSECT
select wl.id_wlasciciela,wlasciciel 
from wlasciciele wl join pojazdy po on (wl.id_wlasciciela=po.id_wlasciciela)
where typ like 'SAM_CIEZAROWY'
group by wl.id_wlasciciela,wlasciciel having count(*)>=2)t1 join pojazdy po
on (t1.id_wlasciciela = po.id_wlasciciela)
group by t1.id_wlasciciela,wlasciciel;


-- zad 8
select st.nr_indeksu, nazwisko, st.rok, pr.rok, nazwa, ocena from 

(select oc.nr_indeksu
from studenci st join oceny oc on(st.nr_indeksu=oc.nr_indeksu) 
join przedmioty pr on(oc.id_przedmiotu=pr.id_przedmiotu)
where st.rok>1 and ocena=5 group by pr.rok, oc.nr_indeksu, st.rok
having count(*)=1
minus
select oc.nr_indeksu
from studenci st join oceny oc on(st.nr_indeksu=oc.nr_indeksu) 
join przedmioty pr on(oc.id_przedmiotu=pr.id_przedmiotu)
where st.rok>1 and ocena=5 group by pr.rok, oc.nr_indeksu, st.rok
having count(*)>1
minus
select t1.nr_indeksu from(
select oc.nr_indeksu, pr.rok, count(ocena) liczba
from studenci st join oceny oc on(st.nr_indeksu=oc.nr_indeksu) 
join przedmioty pr on(oc.id_przedmiotu=pr.id_przedmiotu)
where st.rok>1 group by pr.rok, oc.nr_indeksu, st.rok)t1 join
(select oc.nr_indeksu, pr.rok, count(ocena) liczba
from studenci st join oceny oc on(st.nr_indeksu=oc.nr_indeksu) 
join przedmioty pr on(oc.id_przedmiotu=pr.id_przedmiotu)
where st.rok>1 and ocena !=5 group by pr.rok, oc.nr_indeksu, st.rok)t2 
on(t1.nr_indeksu=t2.nr_indeksu and t1.rok=t2.rok and t1.liczba=t2.liczba))z1
join studenci st on(z1.nr_indeksu=st.nr_indeksu) join oceny oc on(st.nr_indeksu=oc.nr_indeksu) 
join przedmioty pr on(oc.id_przedmiotu=pr.id_przedmiotu)
where ocena=5 order by 1, 4;

-- zad 10
select rok,max(laczna_waga)max_waga , 'najwieksza_waga'komentarz from (
select extract (year from czas)rok ,id_wedkarza ,nvl(sum(waga),0)laczna_waga
from rejestry 
group by  extract (year from czas)  ,id_wedkarza )
group by rok 
union
select rok,round(avg(laczna_waga),3)srednia_waga , 'srednia_waga'komentarz from (
select extract (year from czas)rok ,id_wedkarza ,nvl(sum(waga),0)laczna_waga
from rejestry 
group by  extract (year from czas)  ,id_wedkarza )
group by rok order by 1 ,2;

