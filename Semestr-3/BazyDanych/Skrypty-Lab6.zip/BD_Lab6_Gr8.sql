--zad 1
select to_char(czas,'YYYY-MM-DD HH24:Mi') czas,dlugosc,
'poni�ej sredniej' komentarz
from rejestry where id_gatunku=9 and dlugosc < 58
union
select to_char(czas,'YYYY-MM-DD HH24:Mi') czas,dlugosc,
'powy�ej sredniej' komentarz
from rejestry where id_gatunku=9 and dlugosc > 58
union
select to_char(czas,'YYYY-MM-DD HH24:Mi') czas,dlugosc,
'r�wna sredniej' komentarz
from rejestry where id_gatunku=9 and dlugosc = 58
order by 2;

select imiona from pracownicy
INTERSECT
select imiona from studenci;

select imiona from pracownicy
minus
select imiona from studenci;

select imiona from pracownicy
union --all
select imiona from studenci;

select imiona, nazwisko from pracownicy
union --all
select imiona, adres from studenci;

-- zad 5
select t1.id_gatunku, ga.nazwa, count(*) from (
select id_gatunku from rejestry join lowiska using (id_lowiska)where 
upper(nazwa)='PORAJ'
group by id_gatunku having count(*) >= 1
intersect
select id_gatunku from rejestry join lowiska using (id_lowiska)where 
upper(nazwa)='PILICA'
minus
select id_gatunku from rejestry join wedkarze using (id_wedkarza) where
upper(nazwisko) in ('ANDRYSIAK','KUCZERA'))t1 join gatunki ga 
on(t1.id_gatunku=ga.id_gatunku)join rejestry re on(t1.id_gatunku=re.id_gatunku)
join lowiska lw on(re.id_lowiska=lw.id_lowiska)where upper(lw.nazwa)in
('PILICA', 'PORAJ') group by t1.id_gatunku, ga.nazwa;

-- zad 12
select * from oplaty;

select * from licencje;

select id_okregu,rok,sum(roczna_oplata_pod) kwota,count(*),
'Suma rocznych pod' komentarz from licencje join oplaty using(rok,id_okregu) 
where id_okregu like 'PZW%' group by id_okregu ,rok
union
select id_okregu,rok,sum(roczna_oplata_dod) kwota,count(*),
'Suma rocznych DOD' komentarz from licencje join oplaty using(rok,id_okregu) 
where id_okregu like 'PZW%' and od_dnia like '01-01' and do_dnia like '31-12'
group by id_okregu ,rok
union
select id_okregu,rok,
sum((to_date(do_dnia||'-'||rok,'DD-MM-YYYY') - 
to_date(od_dnia||'-'||rok,'DD-MM-YYYY') +1)* dzienna_oplata)
kwota,count(*),
'Suma dziennych DOD' komentarz from licencje join oplaty using(rok,id_okregu) 
where id_okregu like 'PZW%' and not (od_dnia like '01-01' and do_dnia like '31-12')
group by id_okregu ,rok order by 2,1;

-- zad 17
select * from pracownicy p1 
join pracownicy p2 on (p1.id_dzialu = p2.id_dzialu and p1.nr_akt != p2.nr_akt)
where (p1.data_zwol is null or p1.data_zwol >= sysdate) 
and (p2.data_zwol is null or p2.data_zwol >= sysdate);

select pr.nr_akt, pr.nazwisko, dz.nazwa, pr.placa, 
case when pr.placa = (select max(placa) from pracownicy
where id_dzialu = pr.id_dzialu and (data_zwol is null or data_zwol >= sysdate)) 
then 'zarabia najwiecej'
when pr.placa = (select min(placa) from pracownicy
where id_dzialu = pr.id_dzialu and (data_zwol is null or data_zwol >= sysdate)) 
then 'zarabia najmniej'
else 'prynajmniej ' || (select count(placa) - 1 from pracownicy
where id_dzialu = pr.id_dzialu and (data_zwol is null or data_zwol >= sysdate)
and placa <= pr.placa) || ' mniej niz ' || (select count(placa) from pracownicy
where id_dzialu = pr.id_dzialu and (data_zwol is null or data_zwol >= sysdate)
and placa > pr.placa) end komentarz
from pracownicy pr join dzialy dz on (pr.id_dzialu = dz.id_dzialu) 
where (pr.data_zwol is null or pr.data_zwol >= sysdate);








