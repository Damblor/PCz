
--zad 17
select decode(grouping(tryb), 1, 'Razem', tryb) tryb, stopien, kierunek,
rok, count(*),
GROUPING_ID(tryb, stopien, kierunek, rok) id
from  studenci
group by rollup(tryb, stopien, kierunek, rok)
having GROUPING_ID(tryb, stopien, kierunek, rok) in(1,7,15);


select decode(grouping(tryb), 1, 'Razem', tryb) tryb, stopien, kierunek,
rok, count(*),
GROUPING_ID(tryb, stopien, kierunek, rok) id
from  studenci
group by cube(tryb, stopien, kierunek, rok)
having GROUPING_ID(tryb, stopien, kierunek, rok) in(1,2, 5, 7,10, 15);


select decode(grouping(tryb), 1, 'Razem', tryb) tryb, stopien, kierunek,
rok, count(*),
GROUPING_ID(tryb, stopien, kierunek, rok) id
from  studenci
group by GROUPING SETS ((tryb, stopien, kierunek, rok), 
(tryb, rok), (stopien, kierunek), rok, kierunek, ());

-- zad 1
select to_char(czas,'yyyy-mm-dd hh24:mi')czas_polowu, dlugosc,
'poniezej sredniej'komentarz from rejestry where id_gatunku=9 and dlugosc<58
union
select to_char(czas,'yyyy-mm-dd hh24:mi')czas_polowu, dlugosc,
'rowna sredniej'komentarz from rejestry where id_gatunku=9 and dlugosc=58
union
select to_char(czas,'yyyy-mm-dd hh24:mi')czas_polowu, dlugosc,
'powyzej sredniej'komentarz from rejestry where id_gatunku=9 and dlugosc>58;

--zad 3
Select id_gatunku,nazwa 
from gatunki
minus
Select ga.id_gatunku,nazwa
from rejestry rr join gatunki ga on (rr.id_gatunku=ga.id_gatunku)
group by ga.id_gatunku,nazwa
having count (rr.id_gatunku)>7
;

select t1.id_gatunku,nazwa,count(rr.id_gatunku) 
from 
(Select id_gatunku,nazwa 
from gatunki
minus
Select ga.id_gatunku,nazwa
from rejestry rr join gatunki ga on (rr.id_gatunku=ga.id_gatunku)
group by ga.id_gatunku,nazwa
having count (rr.id_gatunku)>7)t1 left join rejestry rr on
(t1.id_gatunku=rr.id_gatunku) group by t1.id_gatunku,nazwa;

--zad 9
select rr.id_wedkarza
from rejestry rr join lowiska lw on(rr.id_lowiska=lw.id_lowiska)
where id_okregu='PZW Czestochowa' group by rr.id_wedkarza having count(*)>=5
INTERSECT
select rr.id_wedkarza
from rejestry rr join lowiska lw on(rr.id_lowiska=lw.id_lowiska)
where id_okregu not like 'PZW%' group by rr.id_wedkarza having count(*)>=3
INTERSECT
select id_wedkarza from rejestry where extract(year from czas)=2020
group by id_wedkarza having count(id_gatunku)>0;

select * from
(select rr.id_wedkarza
from rejestry rr join lowiska lw on(rr.id_lowiska=lw.id_lowiska)
where id_okregu='PZW Czestochowa' group by rr.id_wedkarza having count(*)>=5
INTERSECT
select rr.id_wedkarza
from rejestry rr join lowiska lw on(rr.id_lowiska=lw.id_lowiska)
where id_okregu not like 'PZW%' group by rr.id_wedkarza having count(*)>=3
INTERSECT
select id_wedkarza from rejestry where extract(year from czas)=2020
group by id_wedkarza having count(id_gatunku)>0) t1 join wedkarze we 
on(t1.id_wedkarza=we.id_wedkarza);

--zad 11
select t1.rok,we.id_wedkarza,nazwisko,laczna_waga, 'max waga' komentarz from
(select rok,max(laczna_waga) max_waga from
(select extract(year from czas)rok,id_wedkarza,sum(nvl(waga,0))laczna_waga
from rejestry
group by extract(year from czas),id_wedkarza)
group by rok) t1 join 
(select extract(year from czas)rok,id_wedkarza,sum(nvl(waga,0))laczna_waga
from rejestry
group by extract(year from czas),id_wedkarza)t2 
on(t1.rok=t2.rok and laczna_waga=max_waga) join wedkarze we 
on (t2.id_wedkarza=we.id_wedkarza)
union
select t1.rok,we.id_wedkarza,nazwisko,laczna_waga, 'min waga' komentarz from
(select rok,min(laczna_waga) min_waga from
(select extract(year from czas)rok,id_wedkarza,sum(nvl(waga,0))laczna_waga
from rejestry
group by extract(year from czas),id_wedkarza)
group by rok) t1 join 
(select extract(year from czas)rok,id_wedkarza,sum(nvl(waga,0))laczna_waga
from rejestry
group by extract(year from czas),id_wedkarza)t2 
on(t1.rok=t2.rok and laczna_waga=min_waga) join wedkarze we 
on (t2.id_wedkarza=we.id_wedkarza)
order by 1,4;

--zad 15
select id_gatunku, nazwa,
case (select nvl(count(DISTINCT id_okregu), 0) from rejestry re join lowiska lw 
on (re.id_lowiska=lw.id_lowiska)where id_gatunku = ga.id_gatunku and id_okregu like 'PZW%')
when 1 then 'jeden okreg'
when 2 then 'dwa okregi'
when 3 then 'trzy okregi'
else 'zero okregow' end komentarz
from gatunki ga;


select nvl(count(DISTINCT id_okregu), 0) from rejestry re join lowiska lw 
on (re.id_lowiska=lw.id_lowiska)where id_gatunku = 19 and id_okregu like 'PZW%';




--zad 1