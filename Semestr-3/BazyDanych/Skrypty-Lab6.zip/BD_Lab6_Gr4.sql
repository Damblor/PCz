 
 select imiona from studenci where stopien=1
 INTERSECT 
 select imiona from studenci where stopien=2;
 
 select imiona from studenci where stopien=1
 MINUS
 select imiona from studenci where stopien=2;
 
 select imiona from studenci where rok=1
 UNION
 select imiona from studenci where rok=2;
 
 
 select imiona, nazwisko from studenci where rok=1
 UNION ALL
 select imiona, 'Kowalski' from studenci where rok=2;
 
 select imiona, nazwisko from studenci where rok=1
 INTERSECT
 select imiona, 'Kowalski' from studenci where rok=2;
 
 select imiona, nazwisko from studenci where rok=1
 INTERSECT
 select imiona, nazwisko from studenci where rok=2;
 
 select INITCAP(nazwa) from gatunki
 INTERSECT
 select nazwisko from studenci;
 
 ------------- 
--zad 2
select to_char(czas, 'yyyy-MM-dd HH24:MI') czas, re.dlugosc, 
case when dlugosc > (select round(avg(dlugosc)) 
from rejestry where id_gatunku = re.id_gatunku) then 'wieksza'
when dlugosc = (select round(avg(dlugosc)) 
from rejestry where id_gatunku = re.id_gatunku) 
then 'rowne' else 'mniejsza'end opis
from rejestry re join gatunki ga on(re.id_gatunku=ga.id_gatunku) where
    lower(nazwa) like 'szczupak';
    

select to_char(czas, 'yyyy-MM-dd HH24:MI') czas, nazwa, re.dlugosc, 
case when dlugosc > (select round(avg(dlugosc)) 
from rejestry where id_gatunku = re.id_gatunku) then 'wieksza'
when dlugosc = (select round(avg(dlugosc)) 
from rejestry where id_gatunku = re.id_gatunku) 
then 'rowne' else 'mniejsza'end opis
from rejestry re join gatunki ga on(re.id_gatunku=ga.id_gatunku) where
    re.id_gatunku is not null;


select t1.id_gatunku, nazwa, srednia, czas, dlugosc, re.id_gatunku,
case
 when dlugosc > srednia then 'wieksza'
 when dlugosc = srednia then 'rowna'
 else 'mniejsza' end opis
from 
(select id_gatunku, round(avg(dlugosc)) srednia from rejestry GROUP BY id_gatunku) t1
join rejestry re on (t1.id_gatunku=re.id_gatunku) join gatunki ga 
on(t1.id_gatunku=ga.id_gatunku);

--- zad 6
select * from (
select id_wedkarza , rok , id_okregu from licencje 
where od_dnia = '01-01' and do_dnia = '31-12' and id_okregu like 'PZW%'
minus
select id_wedkarza, extract(year from czas),id_okregu from rejestry join lowiska
using (id_lowiska) where id_okregu like 'PZW%') t1 
join wedkarze we on(t1.id_wedkarza=we.id_wedkarza);

select rok,nazwisko,t1.id_wedkarza,t1.id_okregu, count(*) from rejestry re join lowiska lw on(re.id_lowiska = lw.id_lowiska) join (
select id_wedkarza , rok , id_okregu from licencje 
where od_dnia = '01-01' and do_dnia = '31-12' and id_okregu like 'PZW%'
intersect
select id_wedkarza, extract(year from czas),id_okregu from rejestry join lowiska
using (id_lowiska) where id_okregu like 'PZW%') t1 on(re.id_wedkarza= t1.id_wedkarza
and t1.id_okregu= lw.id_okregu and t1.rok = extract(year from re.czas))join wedkarze we
on(t1.id_wedkarza=we.id_wedkarza)group by rok,nazwisko,t1.id_wedkarza,t1.id_okregu;

--- zad 13
select t1.typ||' jednej marki najwiecej w ' || t1.dzien || '('||marka||' '|| liczba||')' info 
from (
select typ, dzien, max(liczba) maxliczba from (
select typ, marka, trim(to_char(data_produkcji, 'day')) dzien,count(*) liczba
from pojazdy group by typ, marka, trim(to_char(data_produkcji, 'day')))
group by typ, dzien) t1 join (select typ, marka, trim(to_char(data_produkcji, 'day')) dzien,count(*) liczba
from pojazdy group by typ, marka, trim(to_char(data_produkcji, 'day'))) t2
on(t1.typ=t2.typ and t1.dzien=t2.dzien and maxliczba=liczba)
union
select t1.typ||' jednej marki najmniej w ' || t1.dzien || '('||marka||' '|| liczba||')' info 
from (
select typ, dzien, min(liczba) minliczba from (
select typ, marka, trim(to_char(data_produkcji, 'day')) dzien,count(*) liczba
from pojazdy group by typ, marka, trim(to_char(data_produkcji, 'day')))
group by typ, dzien) t1 join (select typ, marka, trim(to_char(data_produkcji, 'day')) dzien,count(*) liczba
from pojazdy group by typ, marka, trim(to_char(data_produkcji, 'day'))) t2
on(t1.typ=t2.typ and t1.dzien=t2.dzien and minliczba=liczba) order by 1;

--zad 13
select g1.id_gatunku,g1.nazwa,g1.wymiar,
case
when g1.wymiar >g2.wymiar then 'wiekszy'
when g1.wymiar =g2.wymiar then 'rowny'
else 'mniejszy' end opis,
g2.wymiar,g2.id_gatunku,g2.nazwa,
abs(g1.wymiar-g2.wymiar)roznica from gatunki g1 join gatunki g2 
on(g1.id_gatunku<g2.id_gatunku 
and abs(g1.wymiar-g2.wymiar)<=10);

