--zad 2
select to_char (czas,'yyyy-mm-dd hh24:mi')czas, dlugosc, srednia,
case when dlugosc>srednia then 'wieksze' when dlugosc=srednia then 'rowna' else
'mniejsza' end opis
from rejestry re join 
(select round (avg(dlugosc)) srednia, id_gatunku 
from rejestry join gatunki using(id_gatunku)
where lower (nazwa)= 'szczupak' group by id_gatunku) t1 
on (re.id_gatunku=t1.id_gatunku);

-- zad 4
select po.id_wlasciciela, wlasciciel, count(vin),
(select count(*) from pojazdy where id_wlasciciela=po.id_wlasciciela and 
typ like 'SAM_OSOBOWY') licz_SO,
(select count(*) from pojazdy where id_wlasciciela=po.id_wlasciciela and 
typ like 'SAM_CIEZAROWY') licz_SC,
1 Moto
from pojazdy po join
(select id_wlasciciela, wlasciciel from wlasciciele join pojazdy using(id_wlasciciela) 
where typ = 'MOTOCYKL'
group by id_wlasciciela, wlasciciel having count(*) = 1 
intersect
select id_wlasciciela, wlasciciel from wlasciciele join pojazdy using(id_wlasciciela) 
where typ = 'SAM_OSOBOWY'
group by id_wlasciciela, wlasciciel having count(*) >= 1 
intersect
select id_wlasciciela, wlasciciel from wlasciciele join pojazdy using(id_wlasciciela) 
where typ = 'SAM_CIEZAROWY'
group by id_wlasciciela, wlasciciel having count(*) >= 2) p1 
on (po.id_wlasciciela = p1.id_wlasciciela)
group by po.id_wlasciciela, wlasciciel;


-------------------------------

select adres from studenci
union
select imiona from pracownicy;

select * from pracownicy;

select * from gatunki where id_gatunku in
(select id_gatunku from gatunki
minus
select id_gatunku from rejestry);


-- zad 11
select t1.rok,suma ,nazwisko ,imiona,'najwieksza' opis from (
select rok,max(suma) maxy from(
select to_char(czas,'yyyy') rok,id_wedkarza,sum(nvl((waga),0)) suma  from rejestry 
group by to_char(czas,'yyyy'),id_wedkarza)group by rok) t1 join 
(select to_char(czas,'yyyy') rok,id_wedkarza,sum(nvl((waga),0)) suma  from rejestry 
group by to_char(czas,'yyyy'),id_wedkarza) t2 on (t1.rok=t2.rok and maxy=suma) 
join wedkarze we on (t2.id_wedkarza=we.id_wedkarza)
union
select t1.rok,suma ,nazwisko ,imiona,'najmniejsza' opis from (
select rok,min(suma) maxy from(
select to_char(czas,'yyyy') rok,id_wedkarza,sum(nvl((waga),0)) suma  from rejestry 
group by to_char(czas,'yyyy'),id_wedkarza)group by rok) t1 join 
(select to_char(czas,'yyyy') rok,id_wedkarza,sum(nvl((waga),0)) suma  from rejestry 
group by to_char(czas,'yyyy'),id_wedkarza) t2 on (t1.rok=t2.rok and maxy=suma) 
join wedkarze we on (t2.id_wedkarza=we.id_wedkarza) 
order by 1,2 desc,3;

select to_char(czas,'yyyy') rok,avg(waga),imiona,nazwisko 
from rejestry join wedkarze using (id_wedkarza);


-- zad 16
select g1.nazwa, g1.wymiar, g2.nazwa,
case when g1.wymiar > g2.wymiar then 'wiekszy od'
when g1.wymiar<g2.wymiar then 'mniejsze od' else 'rowne'
end opis,
g2.wymiar,abs(g1.wymiar-g2.wymiar)roznica 
from gatunki g1 join gatunki g2 
on (g1.id_gatunku>g2.id_gatunku and abs(g1.wymiar-g2.wymiar)<=10);
