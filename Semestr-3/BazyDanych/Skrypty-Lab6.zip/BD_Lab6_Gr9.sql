
select nazwisko from studenci
intersect
select nazwisko from pracownicy;

select nazwisko from studenci
minus
select nazwisko from pracownicy;

select nazwisko, data_urodzenia, imiona from studenci
union --all
select nazwisko, data_zatr, stanowisko from pracownicy;

-- zad 2
select to_char(czas,'yyyy-mm-dd hh24:mi') czas_polowu,dlugosc,srednia,
case 
when dlugosc<srednia then 'krotsza'
when dlugosc=srednia then 'rowna'
else 'dluzsza' end komentarz
from
(select id_gatunku, round(avg(dlugosc)) srednia from rejestry 
join gatunki using (id_gatunku)
where lower(nazwa) like 'szczupak'
group by id_gatunku) t1 join rejestry re on (t1.id_gatunku = re.id_gatunku);

--zad 6
select rok, id_okregu, id_wedkarza, nazwisko
from licencje join wedkarze using (id_wedkarza)
where id_okregu like 'PZW%'
minus 
select extract (year from czas)rok, id_okregu, id_wedkarza, nazwisko
from rejestry join lowiska using (id_lowiska) join wedkarze using (id_wedkarza)
where id_okregu like 'PZW%';

select rok, id_okregu, t1.id_wedkarza, nazwisko from 
(select rok, id_okregu, id_wedkarza from licencje
where id_okregu like 'PZW%'
minus 
select extract (year from czas)rok, id_okregu, id_wedkarza
from rejestry join lowiska using (id_lowiska) 
where id_okregu like 'PZW%') t1 join wedkarze we on (t1.id_wedkarza = we.id_wedkarza);


select rok, t1.id_okregu, t1.id_wedkarza, nazwisko, count (*)from 
(select rok, id_okregu, id_wedkarza from licencje
where id_okregu like 'PZW%'
intersect
select extract (year from czas)rok, id_okregu, id_wedkarza
from rejestry join lowiska using (id_lowiska) 
where id_okregu like 'PZW%') t1 join wedkarze we
on (t1.id_wedkarza = we.id_wedkarza)join 
(select * from rejestry join lowiska using(id_lowiska)) t2
on (t1.id_wedkarza = t2.id_wedkarza and t1.rok = extract (year from t2.czas) 
and t1.id_okregu=t2.id_okregu)
group by rok, t1.id_okregu, t1.id_wedkarza, nazwisko;

-- zad 13
/*
select typ,dzien, marka, liczba from 
(select typ,marka, max(liczba) liczba
from (select typ,marka, count(*) liczba
from Pojazdy 
group by typ, marka)
group  by ;

select typ,to_char(data_produkcji, 'day'),  max(liczba) liczba
from (select typ,to_char(data_produkcji, 'day'),marka, count(*) liczba
from Pojazdy 
group by typ,to_char(data_produkcji, 'day'), marka)
group by typ;


select typ,to_char(data_produkcji, 'day'),marka, count(*) liczba
from Pojazdy 
group by typ,to_char(data_produkcji, 'day') ,marka;

*/

select t1.typ||' jednej marki najwiecej wyprodukowano w '||t1.dzien||'('||t2.marka||' sztuk '||liczba||')' komentarz from (
select typ,dzien, max(liczba)maks_liczba from (
select typ, to_char(data_produkcji, 'day')dzien,marka, count(*)liczba  from Pojazdy 
group by typ,to_char(data_produkcji, 'day') ,marka)
group by typ, dzien)t1
join (select typ, to_char(data_produkcji, 'day')dzien,marka, count(*)liczba  from Pojazdy 
group by typ,to_char(data_produkcji, 'day') ,marka)t2
on (t1.typ=t2.typ and t1.dzien =t2.dzien and maks_liczba=liczba)
union 
select t1.typ||' jednej marki najmniej wyprodukowano w '||t1.dzien||'('||t2.marka||' sztuk '||liczba||')' komentarz from (
select typ,dzien, min(liczba)minn_liczba from (
select typ, to_char(data_produkcji, 'day')dzien,marka, count(*)liczba  from Pojazdy 
group by typ,to_char(data_produkcji, 'day') ,marka)
group by typ, dzien)t1
join (select typ, to_char(data_produkcji, 'day')dzien,marka, count(*)liczba  from Pojazdy 
group by typ,to_char(data_produkcji, 'day') ,marka)t2
on (t1.typ=t2.typ and t1.dzien =t2.dzien and minn_liczba=liczba)
order by 1 ;




