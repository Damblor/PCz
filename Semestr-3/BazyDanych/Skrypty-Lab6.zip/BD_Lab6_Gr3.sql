
 select nazwisko from studenci
 INTERSECT
 select nazwisko from pracownicy;
 
 
 select nazwisko from studenci
 minus
 select nazwisko from pracownicy;
 
 
 select nazwisko from studenci
 union --all
 select nazwisko from pracownicy;
 
 
 select nazwisko from studenci group by nazwisko having count(*)>=5
 minus
 select nazwisko from pracownicy group by nazwisko having count(*)>=3;

---zad 1
select to_char(czas,'YYYY-MM-DD HH24:MI') czas, dlugosc, 'wieksza' opis
from rejestry where id_gatunku=9 and dlugosc>58
union
select to_char(czas,'YYYY-MM-DD HH24:MI') czas, dlugosc, 'rowna' opis
from rejestry where id_gatunku=9 and dlugosc=58
union
select to_char(czas,'YYYY-MM-DD HH24:MI') czas, dlugosc, 'mniejsze' opis
from rejestry where id_gatunku=9 and dlugosc<58 
order by czas;

-- zad 5
select ga.id_gatunku, ga.nazwa from gatunki ga join rejestry re on 
(ga.id_gatunku=re.id_gatunku)join lowiska lw on (re.id_lowiska=lw.id_lowiska) 
where lw.nazwa='Poraj'
intersect
select ga.id_gatunku, ga.nazwa from gatunki ga join rejestry re on 
(ga.id_gatunku=re.id_gatunku)join lowiska lw on (re.id_lowiska=lw.id_lowiska) 
where lw.nazwa='Pilica'
minus
select ga.id_gatunku, ga.nazwa from gatunki ga join rejestry re on 
(ga.id_gatunku=re.id_gatunku)join wedkarze we on (re.id_wedkarza=we.id_wedkarza) 
where we.nazwisko in('Andrysiak','Kuczera');


select p1.id_gatunku,p1.nazwa,count (*) 
from rejestry re join lowiska lw on (re.id_lowiska=lw.id_lowiska) join
(select ga.id_gatunku, ga.nazwa from gatunki ga join rejestry re on 
(ga.id_gatunku=re.id_gatunku)join lowiska lw on (re.id_lowiska=lw.id_lowiska) 
where lw.nazwa='Poraj'
intersect
select ga.id_gatunku, ga.nazwa from gatunki ga join rejestry re on 
(ga.id_gatunku=re.id_gatunku)join lowiska lw on (re.id_lowiska=lw.id_lowiska) 
where lw.nazwa='Pilica'
minus
select ga.id_gatunku, ga.nazwa from gatunki ga join rejestry re on 
(ga.id_gatunku=re.id_gatunku)join wedkarze we on (re.id_wedkarza=we.id_wedkarza) 
where we.nazwisko in('Andrysiak','Kuczera'))p1 on (re.id_gatunku=p1.id_gatunku)
where lw.nazwa in ('Pilica','Poraj') group by p1.id_gatunku, p1.nazwa;



--zad 11
select p1.rok,laczna,imiona, nazwisko, 'nawieksza' from 
(select rok, max(laczna) maksi from 
(select extract(year from czas) rok,id_wedkarza, sum(nvl(waga,0)) laczna
from rejestry group by extract(year from czas), id_wedkarza)group by rok) p1 
join(select extract(year from czas) rok,id_wedkarza, sum(nvl(waga,0)) laczna
from rejestry group by extract(year from czas), id_wedkarza) p2 on(p1.rok=p2.rok
and maksi = laczna) join wedkarze we on(p2.id_wedkarza=we.id_wedkarza)
union
select p1.rok,laczna,imiona, nazwisko, 'najmniesza' from 
(select rok, min(laczna) mini from 
(select extract(year from czas) rok,id_wedkarza, sum(nvl(waga,0)) laczna
from rejestry group by extract(year from czas), id_wedkarza)group by rok) p1 
join(select extract(year from czas) rok,id_wedkarza, sum(nvl(waga,0)) laczna
from rejestry group by extract(year from czas), id_wedkarza) p2 on(p1.rok=p2.rok
and mini = laczna) join wedkarze we on(p2.id_wedkarza=we.id_wedkarza);

--zad 14
select id_wedkarza, nazwisko, case when (select count (*) from rejestry 
join lowiska using(id_lowiska) where id_wedkarza=we.id_wedkarza
and id_okregu = 'PZW Czestochowa')>0 then 'Tak' else 'Nie' end Czestochowa,
(select count (*) from rejestry 
join lowiska using(id_lowiska) where id_wedkarza=we.id_wedkarza
and id_okregu = 'PZW Czestochowa')liczba,
case when (select count (*) from rejestry 
join lowiska using(id_lowiska) where id_wedkarza=we.id_wedkarza
and id_okregu = 'PZW Opole')>0 then 'Tak' else 'Nie' end Opole,
(select count (*) from rejestry 
join lowiska using(id_lowiska) where id_wedkarza=we.id_wedkarza
and id_okregu = 'PZW Opole')liczba,

case when (select count (*) from rejestry 
join lowiska using(id_lowiska) where id_wedkarza=we.id_wedkarza
and id_okregu not like 'PZW %')>0 then 'Tak' else 'Nie' end Inne,
(select count (*) from rejestry 
join lowiska using(id_lowiska) where id_wedkarza=we.id_wedkarza
and id_okregu not like 'PZW %')liczba
from wedkarze we;
select count (*) from rejestry join lowiska using(id_lowiska) where id_wedkarza=10001
and id_okregu = 'PZW Czestochowa';
--zad 17
select * from pracownicy p1 join pracownicy p2 
on (p1.id_dzialu=p2.id_dzialu and p1.nr_akt=p2.nr_akt);

select nr_akt, nazwisko, nazwa,placa,
case 
when placa=(select max(placa) from pracownicy where id_dzialu=p1.id_dzialu 
and (data_zwol is null or data_zwol>=sysdate)) then 'zarabia najwiecej'
when placa=(select min(placa) from pracownicy where id_dzialu=p1.id_dzialu 
and (data_zwol is null or data_zwol>=sysdate)) then 'zarabia najmniej' 
else 'przynajmniej co ' || (select count(placa)-1 from pracownicy
where id_dzialu=p1.id_dzialu 
and (data_zwol is null or data_zwol>=sysdate)and p1.placa>=placa) || ' ale mniej niz' ||
(select count(placa)-1 from pracownicy
where id_dzialu=p1.id_dzialu 
and (data_zwol is null or data_zwol>=sysdate)and p1.placa<placa)
end info
from pracownicy p1 join dzialy dz 
on (p1.id_dzialu=dz.id_dzialu) where data_zwol is null or data_zwol>=sysdate order by 3,4;

select max(placa) from pracownicy where id_dzialu=10 and (data_zwol is null or data_zwol>=sysdate);



