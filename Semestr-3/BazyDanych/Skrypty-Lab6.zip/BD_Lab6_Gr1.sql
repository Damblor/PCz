--zad 1
select to_char(czas,'YYYY-MM-DD hh24:mi')czas, dlugosc,
case when dlugosc<58 then 'Ponizej' when dlugosc=58 then 'Rowna'
else 'Powyzej' end Opis
from rejestry where id_gatunku=9;

select to_char(czas,'YYYY-MM-DD hh24:mi')czas, dlugosc, 'Ponizej' Opis
from rejestry where id_gatunku=9 and dlugosc<58
union
select to_char(czas,'YYYY-MM-DD hh24:mi')czas, dlugosc, 'Rowne' Opis
from rejestry where id_gatunku=9 and dlugosc=58
union
select to_char(czas,'YYYY-MM-DD hh24:mi')czas, dlugosc, 'Powyzej' Opis
from rejestry where id_gatunku=9 and dlugosc>58;



select imiona from studenci group by imiona having count(*)>=5
minus
select imiona from wedkarze group by imiona having count(*)>=5;

---zad 7
select *from studenci where nr_indeksu in
(select nr_indeksu from studenci join oceny using(nr_indeksu) where ocena = 2
group by nr_indeksu having count(*) >= 3
intersect
select nr_indeksu from studenci join oceny using(nr_indeksu) where ocena = 4
group by nr_indeksu having count(*) >= 6
minus
select nr_indeksu from studenci join oceny using(nr_indeksu) where ocena = 3);

select * from studenci st join (
select nr_indeksu from studenci join oceny using(nr_indeksu) where ocena = 2
group by nr_indeksu having count(*) >= 3
intersect
select nr_indeksu from studenci join oceny using(nr_indeksu) where ocena = 4
group by nr_indeksu having count(*) >= 6
minus
select nr_indeksu from studenci join oceny using(nr_indeksu) where ocena = 3)t1
on (st.nr_indeksu = t1.nr_indeksu);

-- zad 10

select rok,round(avg(laczna_waga),3)srednia,'srednia_z_lacznych wag'opis from (
select extract(year from czas)rok, sum(waga)laczna_waga from rejestry
group by extract(year from czas), id_wedkarza) group by rok
union
select rok,max(laczna_waga)maksymalna,'max waga'opis from (
select extract(year from czas)rok, sum(waga)laczna_waga from rejestry
group by extract(year from czas), id_wedkarza) group by rok 
order by 1,2;

-- zad 14
select id_wedkarza,nazwisko, 
case when  (select count(*) from rejestry join lowiska 
    using (id_lowiska) where id_wedkarza = we.id_wedkarza 
    and id_okregu = 'PZW Czestochowa')>0 then 'TAK'
else 'Nie' 
end "PZW Czestochowa", (select count(*) from rejestry join lowiska 
    using (id_lowiska) where id_wedkarza = we.id_wedkarza 
    and id_okregu = 'PZW Czestochowa') Liczba_Cz,
case when  (select count(*) from rejestry join lowiska 
    using (id_lowiska) where id_wedkarza = we.id_wedkarza 
    and id_okregu = 'PZW Katowice')>0 then 'TAK'
else 'Nie' 
end "PZW Katowice", (select count(*) from rejestry join lowiska 
    using (id_lowiska) where id_wedkarza = we.id_wedkarza 
    and id_okregu = 'PZW Katowice') Liczba_Kat,
case when  (select count(*) from rejestry join lowiska 
    using (id_lowiska) where id_wedkarza = we.id_wedkarza 
    and id_okregu not like 'PZW%')>0 then 'TAK'
else 'Nie' 
end "INNE", (select count(*) from rejestry join lowiska 
    using (id_lowiska) where id_wedkarza = we.id_wedkarza 
    and id_okregu not like 'PZW%') Liczba_Inne
from wedkarze we ;

select count(*) from rejestry join lowiska 
using (id_lowiska) where id_wedkarza = 10001 and id_okregu = 'PZW Czestochowa';

--zad 16
select g1.nazwa, g1.wymiar, 
case when g1.wymiar > g2.wymiar then 'Wiekszy od' 
when g1.wymiar < g2.wymiar then 'Mniejszy od'
else 'Rowny' end Kom, g2.nazwa , g2.wymiar, abs(g1.wymiar - g2.wymiar) roznica
from gatunki g1 join gatunki g2 on(g1.id_gatunku != g2.id_gatunku 
and abs(g1.wymiar - g2.wymiar) <= 10);





