--zad 3

select * from stanowiska st where placa_min <= all(select placa 
from pracownicy where stanowisko = st.stanowisko 
and (data_zwol is null or data_zwol >=sysdate)) and placa_max >= 
all(select placa from pracownicy where stanowisko = st.stanowisko 
and (data_zwol is null or data_zwol >=sysdate)) and 
exists(select * from pracownicy where stanowisko = st.stanowisko 
and (data_zwol is null or data_zwol >=sysdate));

select placa from pracownicy where stanowisko = st.stanowisko 
and (data_zwol is null or dat_zwol >=sysdate);

--zad 5
select * from gatunki ga join rejestry re on(ga.id_gatunku = re.id_gatunku)
join wedkarze we on(we.id_wedkarza = re.id_wedkarza) where dlugosc<wymiar;

select * from gatunki ga where wymiar>any (select dlugosc from rejestry where 
id_gatunku = ga.id_gatunku) and wymiar is not null;

select t1.id_gatunku,nazwa,nazwisko,we.id_wedkarza, 
count(re.id_wedkarza),avg(abs(wymiar-dlugosc))as "srednia roznica"
from (select * from gatunki ga where wymiar>any 
(select dlugosc from rejestry where 
id_gatunku = ga.id_gatunku) and wymiar is not null) t1 join 
rejestry re on(re.id_gatunku = t1.id_gatunku) join wedkarze we 
on(re.id_wedkarza = we.id_wedkarza) where t1.wymiar > dlugosc
group by t1.id_gatunku,nazwa,nazwisko,we.id_wedkarza;

--zad 9
select id_gatunku,nazwa,id_okregu from gatunki ga cross join okregi ok
where id_okregu like 'PZW%' and not exists(select * 
from rejestry  join lowiska using (id_lowiska) where 
id_gatunku=ga.id_gatunku and id_okregu=ok.id_okregu);


select id_gatunku,nazwa,id_okregu from gatunki ga cross join okregi ok
where id_okregu like 'PZW%' and exists(select * 
from rejestry  join lowiska using (id_lowiska) where 
id_gatunku=ga.id_gatunku and id_okregu=ok.id_okregu)
and 
exists
(select count(distinct id_wedkarza)
from rejestry  join lowiska using (id_lowiska) where 
id_gatunku=ga.id_gatunku and id_okregu=ok.id_okregu 
group by id_gatunku, id_okregu
having count(distinct id_wedkarza)>=4);

--zad 13
select * from przedmioty pr where semestr = 1 and stopien = 1 and not exists 
(select * from oceny join studenci using (nr_indeksu) 
where id_przedmiotu = pr.id_przedmiotu and rok = 2 
and (ocena = 2 or ocena is null)) 
and 0<all(select count (*) from oceny join studenci using (nr_indeksu) 
where id_przedmiotu = pr.id_przedmiotu and rok = 3 
and ocena = 5 group by gr_dziekan) 
and not exists (select count (*) from oceny join studenci using (nr_indeksu) 
where id_przedmiotu = pr.id_przedmiotu and rok = 4 
and ocena is null group by gr_dziekan);

select count (*) from oceny join studenci using (nr_indeksu) 
where id_przedmiotu = pr.id_przedmiotu and rok = 4 
and ocena is null group by gr_dziekan;

--zad 14
select stopien,rok, gr_dziekan, count(*), 
listagg(imiona || ' ' || nazwisko, ', ')within group (order by nazwisko) lista
from studenci where imiona like '%a' 
and kierunek='INFORMATYKA' and tryb='STACJONARNY' group by  stopien,rok, gr_dziekan;

select stopien, rok, sum(liczba), 
listagg('gr.'||gr_dziekan||'( '||liczba||': '||lista||')',' +')
within group (order by gr_dziekan) info
from 
(select stopien,rok, gr_dziekan, count(*) liczba, 
listagg(imiona || ' ' || nazwisko, ', ')within group (order by nazwisko) lista
from studenci where imiona like '%a' 
and kierunek='INFORMATYKA' and tryb='STACJONARNY' 
group by  stopien,rok, gr_dziekan)
group by stopien,rok;

--zad 18
select t1.id_okregu, 
listagg(t1.id_lowiska || '(' || waga || ' kg ' || nazwisko ||')', ' * ')within 
group (order by waga desc) info
 from
(select id_okregu, id_lowiska, id_wedkarza, nazwisko, sum(nvl(waga,0)) waga from 
rejestry join lowiska using (id_lowiska) join wedkarze using (id_wedkarza)
group by id_okregu, id_lowiska, id_wedkarza, nazwisko) t1 join
(select id_okregu, id_lowiska, max(waga) maksymalna from 
(select id_okregu, id_lowiska, id_wedkarza, nazwisko, sum(nvl(waga,0)) waga from 
rejestry join lowiska using (id_lowiska) join wedkarze using (id_wedkarza)
group by id_okregu, id_lowiska, id_wedkarza, nazwisko) group by id_okregu,
id_lowiska) t2 on (t1.id_okregu = t2.id_okregu and t1.id_lowiska = t2.id_lowiska
and maksymalna=waga)group by t1.id_okregu ;