--zad 1-2
select* from wedkarze WHERE id_wedkarza =ANY 
(SELECT id_wedkarza FROM rejestry JOIN gatunki USING(id_gatunku)
WHERE LOWER(nazwa) like 'sandacz' AND EXTRACT(Month FROM czas) BETWEEN
6 AND 9);


select* from wedkarze we WHERE id_wedkarza =ANY 
(SELECT id_wedkarza FROM rejestry JOIN gatunki USING(id_gatunku)
WHERE LOWER(nazwa) LIKE 'sandacz' AND EXTRACT(Month FROM czas) BETWEEN
6 AND 9) AND 60<=ALL(SELECT dlugosc FROM rejestry JOIN gatunki USING(id_gatunku)
WHERE LOWER(nazwa) LIKE 'sandacz' AND EXTRACT(Month FROM czas) BETWEEN
6 AND 9 AND id_wedkarza=we.id_wedkarza);

--zad 8
select * from studenci st where rok>=2 and 4.3<=all
(select avg(ocena) from oceny join przedmioty using(id_przedmiotu) 
where nr_indeksu =st.nr_indeksu group by rok) and 4.6>=all(select avg(ocena)
from oceny join przedmioty using(id_przedmiotu) 
where nr_indeksu =st.nr_indeksu group by rok) and not exists(select *
from oceny join przedmioty using(id_przedmiotu) 
where nr_indeksu =st.nr_indeksu and (ocena=2.0 or ocena is null));

-- zad 10
select * from wedkarze w1 where 0< all (
select ( select count(*) from rejestry 
where extract(year from czas)=t1.rok and id_wedkarza=we.id_wedkarza)
from (
select extract(year from czas) rok from rejestry group by extract(year from czas)) t1 
cross join wedkarze we where we.id_wedkarza=w1.id_wedkarza);

select count(*) from rejestry where extract(year from czas)=2013 and id_wedkarza=10001;

-- 11
select * from wedkarze we where 0 < all(
select count(*) - count(id_gatunku) fail from rejestry 
where id_wedkarza = we.id_wedkarza 
group by id_lowiska) and exists(select * from rejestry 
where id_wedkarza = we.id_wedkarza) and exists(select sum(waga) from rejestry
where id_wedkarza = we.id_wedkarza group by id_lowiska having sum(waga) >= 1);

--14
SELECT stopien, rok, gr_dziekan, COUNT(*) liczba, ROUND (AVG (srednia),2) srednia,
listaGG(nazwisko|| ' ' || imiona, ', ') WITHIN GROUP (ORDER BY nazwisko) lista
FROM studenci 
WHERE kierunek LIKE 'INFORMATYKA' AND tryb LIKE 'STACJONARNY' AND imiona LIKE '%a'
GROUP BY stopien, rok, gr_dziekan;

SELECT stopien, rok, SUM(liczba), AVG(srednia),
listaGG('GR.'||gr_dziekan||' liczba=' || liczba ||
' srednia='|| srednia||' ['|| lista||']', '  #  ') 
WITHIN GROUP (ORDER BY gr_dziekan) info FROM 
(SELECT stopien, rok, gr_dziekan, COUNT(*) liczba, ROUND (AVG (srednia),2) srednia,
listaGG(nazwisko|| ' ' || imiona, ', ') WITHIN GROUP (ORDER BY nazwisko) lista
FROM studenci 
WHERE kierunek LIKE 'INFORMATYKA' AND tryb LIKE 'STACJONARNY' AND imiona LIKE '%a'
GROUP BY stopien, rok, gr_dziekan) GROUP BY stopien, rok;


