--zad 3
select * from stanowiska st where placa_min <= all
(select placa from pracownicy where stanowisko = st.stanowisko  and
(data_zwol is null or data_zwol >= sysdate)) and placa_max >= all
(select placa from pracownicy where stanowisko = st.stanowisko  and
(data_zwol is null or data_zwol >= sysdate)) and exists 
(select * from pracownicy where stanowisko = st.stanowisko  and
(data_zwol is null or data_zwol >= sysdate)) and not exists 
(select stanowisko from pracownicy where stanowisko = st.stanowisko  and
(data_zwol is null or data_zwol >= sysdate)group by stanowisko having count (*)>= 5);


-- zad 4
select distinct id_gatunku,nazwa from gatunki join rejestry using 
(id_gatunku)where dlugosc<=wymiar order by 1;

select * from gatunki where id_gatunku=any
(select  id_gatunku from gatunki join rejestry using 
(id_gatunku)where dlugosc<=wymiar);

select  id_gatunku from gatunki join rejestry using 
(id_gatunku)where dlugosc<=wymiar order by 1;

--zad 6
select id_okregu,id_gatunku, nazwa from gatunki ga cross join( 
select id_okregu from lowiska where id_okregu like 'PZW%' group by id_okregu) p1 where
exists(select * from rejestry join lowiska using(id_lowiska)where 
id_gatunku = ga.id_gatunku and id_okregu = p1.id_okregu);


select id_okregu,id_gatunku, nazwa from gatunki ga cross join( 
select id_okregu from lowiska where id_okregu like 'PZW%' group by id_okregu) p1 where
exists(select extract(year from czas) from rejestry join lowiska using(id_lowiska)where 
id_gatunku = ga.id_gatunku and id_okregu = p1.id_okregu group by 
extract(year from czas) having count(distinct id_wedkarza) >= 3);

--13
select * from przedmioty pr where semestr=1 and not exists
(select * from studenci join oceny using(nr_indeksu) where (ocena=2 or ocena is null)
and id_przedmiotu=pr.id_przedmiotu) and 5=all(
select max(nvl(ocena, 0)) from studenci join oceny using(nr_indeksu) where
id_przedmiotu=pr.id_przedmiotu and rok=3 group by gr_dziekan, zakres, tryb, kierunek
) and not exists(
select * from studenci join oceny using(nr_indeksu) where rok=4 and ocena is null
and id_przedmiotu=pr.id_przedmiotu);

-- zad 15
select nazwa, count(*) liczba,
listagg(nazwisko||' '||waga, ', ')within group(order by nazwisko, waga) lista
from rejestry join gatunki using(id_gatunku) 
join wedkarze using (id_wedkarza) group by nazwa;

select nazwa, sum(liczba), sum(l_waga), 
listagg('mm= '||miesiac||' liczba= '||liczba||' '||l_waga||' kg ['||lista||']','++')
within group(order by miesiac) info from 
(select extract(month from czas) miesiac, nazwa, count(*) liczba, sum(waga) l_waga,
listagg(nazwisko||' '||waga, ', ')within group(order by nazwisko, waga) lista
from rejestry join gatunki using(id_gatunku) 
join wedkarze using (id_wedkarza) group by nazwa, extract(month from czas))
group by nazwa;

