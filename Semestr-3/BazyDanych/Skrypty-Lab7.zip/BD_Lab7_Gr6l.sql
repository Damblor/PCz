--zad 1
select * from wedkarze where id_wedkarza = any(
select id_wedkarza from rejestry join gatunki using (id_gatunku)
where lower(nazwa) = 'sandacz' and extract(month from czas) between 6 and 9);

select * from wedkarze wl where not exists(
select * from rejestry join gatunki using (id_gatunku)
where lower(nazwa) = 'sandacz' and extract(month from czas) between 6 and 9 and 
id_wedkarza = wl.id_wedkarza);

--zad 4
select * from gatunki ga where wymiar is not null and wymiar > any (
    select dlugosc from rejestry where id_gatunku = ga.id_gatunku);
    
    
select * from gatunki ga where wymiar is not null and wymiar <= all (
    select dlugosc from rejestry where id_gatunku = ga.id_gatunku)
    and exists (select * from rejestry where id_gatunku = ga.id_gatunku);
    
--zad 8
select * from studenci st where rok >= 2 and 4.3 <= all
(select avg(ocena) from przedmioty join oceny using (id_przedmiotu)
where nr_indeksu = st.nr_indeksu
group by nr_indeksu, rok) and 4.6 >= all
(select avg(ocena) from przedmioty join oceny using (id_przedmiotu)
where nr_indeksu = st.nr_indeksu
group by nr_indeksu, rok) and exists
(select * from przedmioty join oceny using (id_przedmiotu)
where nr_indeksu = st.nr_indeksu and (ocena = 2 or ocena is null));

-- zad 11
select * from wedkarze we where 0 < all
(select count(*)-count(id_gatunku) from rejestry where id_wedkarza = we.id_wedkarza
group by id_lowiska) and exists (select count(*)-count(id_gatunku) from rejestry where id_wedkarza = we.id_wedkarza
group by id_lowiska);

--zad 15
select nazwa,count(*) liczba,listagg(nazwisko||' '||id_lowiska,', ')within group
(order by nazwisko) lista
from rejestry join gatunki using (id_gatunku) join wedkarze 
using (id_wedkarza) group by nazwa;


select nazwa, sum(liczba) liczba, listagg(wedkarz||'( ' ||liczba || ')','# ')
within group
(order by liczba desc) info from ( 
select nazwa,id_wedkarza,nazwisko||' '||substr(imiona,1,1)||'.'wedkarz,
count(*) liczba from rejestry join gatunki using (id_gatunku) join wedkarze 
using (id_wedkarza) group by nazwa,id_wedkarza,nazwisko||' '||
substr(imiona,1,1)||'.') group by nazwa;

-- zad 10
select * from wedkarze we2 where 


select rok, id_wedkarza,(
select count(*) from rejestry where id_wedkarza = we.id_wedkarza and rok
= extract(year from czas)) from
(select distinct extract(year from czas)rok from rejestry) t1 cross join wedkarze we
GROUP BY rok, id_wedkarza;

select * from wedkarze wz where 0 < all(
select (
select count(*) from rejestry where id_wedkarza = we.id_wedkarza and rok
= extract(year from czas)) from
(select distinct extract(year from czas)rok from rejestry) t1 cross join wedkarze we
WHERE we.id_wedkarza = wz.id_wedkarza);









