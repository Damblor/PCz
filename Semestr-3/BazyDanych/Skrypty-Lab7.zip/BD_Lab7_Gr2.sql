--zad 3
select * from stanowiska st where placa_min<= all(
select placa from pracownicy where stanowisko =st.stanowisko and
(data_zwol is null or data_zwol >=sysdate))and placa_max >= all (select placa from pracownicy where stanowisko =st.stanowisko and
(data_zwol is null or data_zwol >=sysdate)) and not EXISTS (select * from pracownicy where stanowisko =st.stanowisko and
(data_zwol is null or data_zwol >=sysdate)) ;



select * from stanowiska st where placa_min<= all(
select placa from pracownicy where stanowisko =st.stanowisko and
(data_zwol is null or data_zwol >=sysdate))and placa_max >= all (select placa from pracownicy where stanowisko =st.stanowisko and
(data_zwol is null or data_zwol >=sysdate)) and  
EXISTS (select stanowisko from pracownicy where stanowisko =st.stanowisko and
(data_zwol is null or data_zwol >=sysdate)
group by stanowisko having count (*)>=3) ;

--zad 6
select * from (
select id_okregu from lowiska where id_okregu like 'PZW%' group by id_okregu) t1
cross join
(select id_gatunku, nazwa from gatunki) t2 where
exists(select * from rejestry join lowiska using (id_lowiska)
where id_gatunku = t2.id_gatunku and id_okregu = t1.id_okregu);

--zad 7
select * from (
select id_okregu from lowiska where id_okregu like 'PZW%' group by id_okregu) t1
cross join
(select id_gatunku, nazwa from gatunki) t2 where
exists(select * from rejestry join lowiska using (id_lowiska)
where id_gatunku = t2.id_gatunku and id_okregu = t1.id_okregu
group by Extract(year from czas), id_okregu, id_gatunku 
having count(distinct id_wedkarza) >= 3) and 
exists (select * from rejestry join lowiska using (id_lowiska)
where id_gatunku = t2.id_gatunku and id_okregu = t1.id_okregu and 
trim(to_char(czas, 'DAY'))='SOBOTA' ) ;

--ZAD 11
select * from wedkarze w1 where 0<all(
select count(*)-count(id_gatunku) from rejestry 
where id_wedkarza=w1.id_wedkarza group by id_lowiska) 
and exists(select * from rejestry 
where id_wedkarza=w1.id_wedkarza ) ;

--zad 14

select stopien, rok, gr_dziekan , count(*) liczba, 
listagg(nazwisko || ' ' || imiona, ', ')within group(order by nazwisko) lista
from studenci 
where kierunek='INFORMATYKA'and tryb='STACJONARNY' and Imiona like'%a'
group by stopien, rok, gr_dziekan;

select stopien, rok, sum(liczba), 
listagg('gr.'||gr_dziekan|| ' liczba='||liczba||'['||lista||']','###')within group
(order by gr_dziekan)info from(
select stopien, rok, gr_dziekan , count(*) liczba, 
listagg(nazwisko || ' ' || imiona, ', ')within group(order by nazwisko) lista
from studenci 
where kierunek='INFORMATYKA'and tryb='STACJONARNY' and Imiona like'%a'
group by stopien, rok, gr_dziekan)group by stopien, rok;

--zad 18
select t1.id_okregu, listagg(t1.id_lowiska|| '('|| l_waga||'kg '||nazwisko||')','*')
within group(order by l_waga desc)info from(
select id_okregu, id_lowiska, max(l_waga)max_waga from (
select nvl(id_okregu, 'brak')id_okregu, id_lowiska, id_wedkarza, sum(nvl(waga,0))l_waga 
from rejestry join lowiska using(id_lowiska)
group by nvl(id_okregu,'brak'), id_lowiska, id_wedkarza)
group by id_okregu,id_lowiska)t1 join(
select nvl(id_okregu, 'brak')id_okregu, id_lowiska, id_wedkarza,nazwisko, sum(nvl(waga,0))l_waga 
from rejestry join lowiska using(id_lowiska) join wedkarze using(id_wedkarza)
group by nvl(id_okregu,'brak'), id_lowiska, id_wedkarza,nazwisko)t2
on (t1.id_okregu=t2.id_okregu and t1.id_lowiska=t2.id_lowiska and max_waga=l_waga)
group by t1.id_okregu;



