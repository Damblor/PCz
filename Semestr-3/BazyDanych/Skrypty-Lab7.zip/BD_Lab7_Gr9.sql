--zad 1
select * from wedkarze ws where id_wedkarza = any 
(select id_wedkarza from rejestry join gatunki using(id_gatunku) 
where lower(nazwa) like 'sandacz'  and extract(month from czas) between 6 and 9);

select * from wedkarze ws where 
 exists
(select * from rejestry join gatunki using(id_gatunku) 
where lower(nazwa) like 'sandacz' and extract(month from czas) between 6 and 9
and id_wedkarza=ws.id_wedkarza);

select * from wedkarze ws where 
 exists
(select count(*) from rejestry join gatunki using(id_gatunku) 
where lower(nazwa) like 'sandacz' and extract(month from czas) between 6 and 9
and id_wedkarza=ws.id_wedkarza group by id_wedkarza having count(*)>=3);

-- zad 8
select * from studenci st where rok>=2 and 4.3 <= all 
(select avg(ocena) from przedmioty
join oceny using(id_przedmiotu) where nr_indeksu = st.nr_indeksu 
group by rok) and 4.6 >= all(select avg(ocena) from przedmioty
join oceny using(id_przedmiotu) where nr_indeksu = st.nr_indeksu 
group by rok) and exists 
(select * from oceny where
nr_indeksu = st.nr_indeksu and (ocena is null or ocena = 2))
and exists(select avg(ocena) from przedmioty
join oceny using(id_przedmiotu) where nr_indeksu = st.nr_indeksu 
group by rok);

--zad 9
select id_okregu, id_gatunku, nazwa from okregi ok cross join gatunki ga
where id_okregu like 'PZW%' and not exists (select * from rejestry 
join lowiska using (id_lowiska) where id_gatunku = ga.id_gatunku 
and id_okregu = ok.id_okregu); 


select id_okregu, id_gatunku, nazwa from okregi ok cross join gatunki ga
where id_okregu like 'PZW%' and  exists (select count(*) from rejestry 
join lowiska using (id_lowiska) where id_gatunku = ga.id_gatunku 
and id_okregu = ok.id_okregu group by id_lowiska having count(*)>=10);

-- zad 15
SELECT nazwa, count (*), listagg(nazwisko || ' ' || waga || 'kg', ', ') 
within group (order by nazwisko) lista
from rejestry join gatunki using (id_gatunku)
join wedkarze using(id_wedkarza) group by nazwa;


--zad16
SELECT nazwa, sum(liczba), sum(waga), 
listagg(nazwisko || ' : ' ||  liczba || ' szt ' || waga || 'kg', ' # ') 
within group (order by liczba desc, id_wedkarza) info from (
SELECT nazwa, id_wedkarza, nazwisko, count (*) liczba, sum(waga) waga 
from rejestry join gatunki using (id_gatunku)
join wedkarze using(id_wedkarza) group by  id_wedkarza, nazwisko, nazwa) 
group by nazwa;

--zad 10
select * from wedkarze z1 where 0<all
(select (select count(*) from rejestry 
where id_wedkarza=we.id_wedkarza and extract(year from czas)=rok)liczba
from 
(select extract(year from czas) rok from rejestry 
group by extract(year from czas)) t1 cross join wedkarze we
where we.id_wedkarza=z1.id_wedkarza)and exists(select * from rejestry 
where id_wedkarza=z1.id_wedkarza);


