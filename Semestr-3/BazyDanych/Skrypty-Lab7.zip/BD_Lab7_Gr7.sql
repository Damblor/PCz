--zad 1

select * from Wedkarze we where id_wedkarza = any(
select rejestry.id_wedkarza from Rejestry join Gatunki using(id_gatunku) 
where upper (gatunki.nazwa) like 'SANDACZ' 
AND extract(month from czas) between 6 and 9) and
60 <= all(
select dlugosc from Rejestry join Gatunki using(id_gatunku) 
where upper (gatunki.nazwa) like 'SANDACZ' and id_wedkarza = we.id_wedkarza
AND extract(month from czas) between 6 and 9) and
exists (
select dlugosc from Rejestry join Gatunki using(id_gatunku) 
where upper (gatunki.nazwa) like 'SANDACZ' and id_wedkarza = we.id_wedkarza
AND extract(month from czas) between 6 and 9);


--zad 6
select ok.id_okregu, ga.id_gatunku, nazwa
from okregi ok cross join gatunki ga 
where exists(select * from rejestry join lowiska using(id_lowiska) 
where ga.id_gatunku=id_gatunku and ok.id_okregu=id_okregu);

--zad 7
select ok.id_okregu, ga.id_gatunku, nazwa
from okregi ok cross join gatunki ga 
where exists(select extract(year from czas) from rejestry join
lowiska using(id_lowiska) 
where ga.id_gatunku=id_gatunku and ok.id_okregu=id_okregu
group by extract(year from czas) having count(distinct id_wedkarza) >= 3);

--zad 12
select *
from lowiska lw where 1<= all(
select sum(waga) from rejestry
where id_lowiska=lw.id_lowiska
group by extract(year from czas))
and 10< any (
select sum(waga) from rejestry
where id_lowiska=lw.id_lowiska
group by extract(year from czas))
and exists (select * from rejestry join gatunki using (id_gatunku) where nazwa like 'SZCZUPAK' 
and id_lowiska=lw.id_lowiska) ;

-- zad 14
select stopien, rok, gr_dziekan, count(*) liczba, 
listagg(imiona||' '||nazwisko, ', ') within group (order by nazwisko) lista
from studenci 
where kierunek like 'INFORMATYKA' and tryb like 'STACJONARNY' 
and imiona like '%a'
group by stopien, rok, gr_dziekan;

select stopien, rok, sum(liczba), 
listagg('gr.'||gr_dziekan||' '||liczba||' '|| lista,'# ') 
within group(order by gr_dziekan) opis from (
select stopien, rok, gr_dziekan, count(*) liczba, 
listagg(imiona||' '||nazwisko, ', ') within group (order by nazwisko) lista
from studenci 
where kierunek like 'INFORMATYKA' and tryb like 'STACJONARNY' 
and imiona like '%a'
group by stopien, rok, gr_dziekan) group by stopien, rok;

--zad 17
select nr_indeksu, nazwisko, kierunek, rok, sum(liczba), 
listagg (ocena||' ('||liczba||'szt. )',', ') within group (order by ocena) opis
from (
select nr_indeksu, nazwisko, kierunek, rok, 
decode(ocena, null, 'BRAK',ocena) ocena, 
count(*)liczba from studenci join oceny
using(nr_indeksu) group by nr_indeksu, nazwisko, kierunek, rok, 
decode(ocena, null, 'BRAK',ocena)) group by 
nr_indeksu, nazwisko, kierunek, rok;

--zad 10
select * from wedkarze wee where 0 < all(
select(select count (*) from rejestry where id_wedkarza=we.id_wedkarza
and extract(year from czas)=d1.rok)
from(select distinct extract(year from czas) rok from rejestry) d1
cross join wedkarze we where we.id_wedkarza=wee.id_wedkarza)
and exists (select * from rejestry where id_wedkarza=wee.id_wedkarza);



