--zad 1-2
select id_wedkarza, nazwisko, imiona from wedkarze w1 where id_wedkarza = any
(select id_wedkarza from rejestry join gatunki using (id_gatunku) where
nazwa like 'SANDACZ' AND extract(MONTH from CZAS) between 6 and 9)
and 60 <= all (select dlugosc from rejestry join gatunki using (id_gatunku) where
nazwa like 'SANDACZ' AND extract(MONTH from CZAS) between 6 and 9 
and id_wedkarza = w1.id_wedkarza);

--zad 6
select * from Lowiska,Gatunki,rejestry;
select * from
(select id_okregu from lowiska where id_okregu like 'PZW%' group by id_okregu)p1
cross join (select id_gatunku,nazwa from gatunki)p2 where exists 
(select * from rejestry join lowiska using (id_lowiska) where id_okregu = p1.id_okregu 
and id_gatunku=p2.id_gatunku) ;

-- zad 7

select * from
(select id_okregu from lowiska where id_okregu like 'PZW%' group by id_okregu)p1
cross join (select id_gatunku,nazwa from gatunki)p2 
where  exists 
(select id_gatunku from rejestry join lowiska using (id_lowiska) 
where id_okregu = p1.id_okregu and id_gatunku=p2.id_gatunku
group by id_gatunku,id_okregu having count(distinct id_wedkarza)>=3);

--12
select * from lowiska lw where 1<= all(
select sum(nvl(waga,0)) from rejestry where id_lowiska = lw.id_lowiska
group by extract(year from czas)) and 10<= any (
select sum(nvl(waga,0)) from rejestry where id_lowiska = lw.id_lowiska
group by extract(year from czas)) and exists(
select * from rejestry join gatunki using (id_gatunku) where nazwa like 'SZCZUPAK'
and id_lowiska = lw.id_lowiska);

-- zad 14
select stopien, rok, gr_dziekan, count(*) liczba,
listagg(nazwisko || ' ' || imiona, ', ') within group (order by nazwisko) lista
from studenci 
where kierunek like 'INFORMATYKA' and tryb like 'STACJONARNY'
and imiona like '%a' group by stopien, rok, gr_dziekan;

select stopien, rok, sum(liczba),
listagg('GR.' || gr_dziekan ||' ' || liczba || ' p. (' || lista || ')' , '# ') 
within group (order by gr_dziekan) info 
from(select stopien, rok, gr_dziekan, count(*) liczba,
listagg(nazwisko || ' ' || imiona, ', ') within group (order by nazwisko) lista
from studenci 
where kierunek like 'INFORMATYKA' and tryb like 'STACJONARNY'
and imiona like '%a' group by stopien, rok, gr_dziekan) group by stopien, rok;

-- 17
select nr_indeksu, nazwisko, kierunek,rok, sum(liczba),
listagg(ocena || ' (' || liczba || ' szt)',', ') within group (order by ocena) info
from(
select nr_indeksu, nazwisko, kierunek,rok, decode(ocena,null,'Brak',ocena) ocena ,
count(*)liczba from studenci join oceny using (nr_indeksu) 
group by nr_indeksu, nazwisko, kierunek,rok, decode(ocena,null,'Brak',ocena)) 
group by nr_indeksu, nazwisko, kierunek,rok;








