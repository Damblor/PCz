--zad 1-2
select id_wedkarza , nazwisko , imiona , data_ur from wedkarze we
where id_wedkarza = SOME(select id_wedkarza from rejestry 
join gatunki using(id_gatunku) where extract(month from czas) between 6 and 9 and
upper (nazwa) like 'SANDACZ' group by id_wedkarza having count(id_gatunku) >=1) 
and 60 <= ALL(select dlugosc from rejestry join gatunki using (id_gatunku)
where upper (nazwa) like 'SANDACZ' and id_wedkarza=we.id_wedkarza and 
extract(month from czas) between 6 and 9);

select dlugosc from rejestry join gatunki using (id_gatunku)
where upper (nazwa) like 'SANDACZ' and id_wedkarza=we.id_wedkarza;

-- zad 3

select * from stanowiska st
where placa_min <= all(select placa from pracownicy 
where stanowisko=st.stanowisko and (data_zwol is null or data_zwol >= sysdate))
and placa_max >= all(select placa from pracownicy 
where stanowisko=st.stanowisko and (data_zwol is null or data_zwol >= sysdate))
and EXISTS(select placa from pracownicy 
where stanowisko=st.stanowisko and (data_zwol is null or data_zwol >= sysdate));


--zad 9
select * from (select id_okregu from okregi where id_okregu like 'PZW%') t1
cross join gatunki
;

select id_okregu, nazwa, id_gatunku from okregi ok
cross join gatunki ga where id_okregu like 'PZW%'
and not exists (select * from rejestry join lowiska using(id_lowiska) where
id_okregu = ok.id_okregu and id_gatunku=ga.id_gatunku);


--zad 13
select * from przedmioty pr where semestr=1 and stopien=1 and 
not exists(select * from oceny join studenci using(nr_indeksu) 
where rok=2 and id_przedmiotu=pr.id_przedmiotu and (ocena=2.0 or ocena is null))
and 5=all(select max(ocena) from oceny join studenci using(nr_indeksu) 
where rok=3 and id_przedmiotu=pr.id_przedmiotu 
group by gr_dziekan) and not exists(select * from oceny join studenci using(nr_indeksu) 
where rok=4 and id_przedmiotu=pr.id_przedmiotu and ocena is null);

select * from oceny join studenci using(nr_indeksu) 
where rok=4 and id_przedmiotu=pr.id_przedmiotu and ocena is null;



select id_okregu from okregi
where id_okregu like 'PZW%'
;

--15
select nazwa, count(*)liczba,listagg(nazwisko||' '||id_lowiska, ', ')within group(order by nazwisko)lista
from rejestry JOIN wedkarze using (id_wedkarza)join gatunki using (id_gatunku)
group by nazwa;

select nazwa, rok, sum (liczba)sliczba, sum(lwaga)swaga,
listagg(id_wedkarza||' '||nazwisko||': '||liczba||' szt'||' waga '||lwaga,' * ')
within group (order by id_wedkarza)lista from( 
select extract (year from czas)rok, nazwa,id_wedkarza,nazwisko, count(*)liczba,sum (waga)lwaga
from rejestry JOIN wedkarze using (id_wedkarza)join gatunki using (id_gatunku)
group by nazwa,nazwisko,extract (year from czas),id_wedkarza)group by nazwa, rok;

select nazwa, sum(sliczba), sum(swaga),
listagg(rok||' '||sliczba||' szt'||swaga||' kg ['||lista||']','##')
within group(order by rok)info from (
select nazwa, rok, sum (liczba)sliczba, sum(lwaga)swaga,
listagg(id_wedkarza||' '||nazwisko||': '||liczba||' szt'||' waga '||lwaga,' * ')
within group (order by id_wedkarza)lista from( 
select extract (year from czas)rok, nazwa,id_wedkarza,nazwisko, count(*)liczba,sum (waga)lwaga
from rejestry JOIN wedkarze using (id_wedkarza)join gatunki using (id_gatunku)
group by nazwa,nazwisko,extract (year from czas),id_wedkarza)group by nazwa, rok)
group by nazwa;