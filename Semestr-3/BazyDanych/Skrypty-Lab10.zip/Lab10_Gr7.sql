--zad 2
create global temporary table Najnizsze_Srednie
(
    kierunek varchar2(150),
    tryb varchar2(30),
    stopien number(1),
    nr_indeksu number(6),
    srednia number(3,2)
) on commit delete rows;

create global temporary table Najwyzsze_Srednie
(
    kierunek varchar2(150),
    tryb varchar2(30),
    stopien number(1),
    nr_indeksu number(6),
    srednia number(3,2)
) on commit delete rows;

select * from (
select kierunek, tryb, stopien, max(srednia) max_srednia, min(srednia) min_srednia from studenci
group by kierunek, tryb, stopien
)t1 join studenci st on(t1.kierunek= st.kierunek and t1.tryb = st.tryb and t1.stopien = st.stopien
and (srednia = max_srednia or srednia = min_srednia));

insert all
when srednia = min_srednia then into Najnizsze_Srednie values (kier,tryb,sto,nr_indeksu,srednia)
when srednia = max_srednia then into Najwyzsze_Srednie values (kier,tryb,sto,nr_indeksu,srednia)
select st.kierunek kier, st.tryb, st.stopien sto, nr_indeksu, srednia, min_srednia, max_srednia from (
select kierunek, tryb, stopien, max(srednia) max_srednia, min(srednia) min_srednia from studenci
group by kierunek, tryb, stopien
)t1 join studenci st on(t1.kierunek= st.kierunek and t1.tryb = st.tryb and t1.stopien = st.stopien
and (srednia = max_srednia or srednia = min_srednia));

select * from Najnizsze_Srednie;

commit;

drop table Najnizsze_Srednie;
drop table Najwyzsze_Srednie;

--zad 3
create table Zak
(
id_studenta number(6) PRIMARY KEY,
nazwisko varchar(20),
imie varchar(15),
pseudonim varchar(30),
kierunek varchar(20),
stopien number(1),
semestr number(1) check(semestr between 1 and 8)
);

create sequence Zak_id_seq
start with 99985
minvalue 10000
maxvalue 99999
increment by 10
cycle;

insert into zak values(Zak_id_seq.nextval, 'KOWALSKI', 'ROMAN', 'KOWAL',  'INFORMATYKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'NOWAK', 'ANNA', 'NOWA', 'INFORMATYKA',  1, 3);
insert into zak values(Zak_id_seq.nextval, 'PIECH', 'EWA', 'PEWA',  'MECHANIKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'POLAK', 'IZABELA', 'IZA',  'MECHANIKA', 2, 4);

select * from zak;
select Zak_id_seq.currval from dual;

--Zad 4 
alter SEQUENCE Zak_id_seq INCREMENT by 11;

insert into zak values(Zak_id_seq.nextval, 'WAWRZYNIEC', 'DAMIAN','WAWRZYN',  'INFORMATYKA',  2, 3);
insert into zak values(Zak_id_seq.nextval, 'KOSSAK', 'KATARZYNA', 'KOSA', 'INFORMATYKA',  1, 2);

select * from zak;
--Zad 5
create index ind_kier on zak (kierunek);
create index ind_sem on zak (semestr, stopien);
create UNIQUE index ind_pseudo on zak (pseudonim);

insert into zak values((select max(id_studenta) from zak)+1, 'WAWRZYNIEC', 'JAN','WAWRZYN2',  'MATEMATYKA',  1, 2);
insert into zak values((select max(id_studenta) from zak)+1, 'WAWRZYNIEC', 'ADAM','WAWRZYN3',  'MATEMATYKA',  1, 2);

drop index ind_kier;
drop table zak CASCADE CONSTRAINTS;

--Zad 6
create table StudenciBis as select * from studenci;

selecT * from studencibis; 

create or replace view studentki as select * from studencibis 
where imiona like '%a' order by nazwisko,imiona;

select * from studentki;

create or replace view zacy as select * from studencibis 
where imiona not like '%a' order by nazwisko,imiona with read only;

insert into Zacy values(123456, 'Testowski', 'Test', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Test', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Testa', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);

select * from studentki where nazwisko like 'Test%';
select * from zacy where nazwisko like 'Test%';
select * from studencibis where nazwisko like 'Test%';
--zad 7
insert into S1R1 values(12345, 'RAKOWSKI', 'TOMASZ', 1, 'RT12345');

--zad 8
create table PracownicyBis as select * from pracownicy;
create or replace view lista_plac as
select nr_akt,nazwisko,id_dzialu,stanowisko,placa+placa*dod_staz*0.01
+nvl(dod_funkcyjny,0)-nvl(koszt_ubezpieczenia,0) pensja 
from pracownicyBis
where nr_akt>=1000 and (data_zwol is null or data_zwol>=sysdate)
order by id_dzialu,nazwisko
with check option;

INSERT INTO Lista_Plac VALUES(1222, 'TESTOWSKI', 10, 'INFORMATYK', 5000);

SELECT * FROM Lista_plac; 

 
--Zad 9
INSERT INTO Szefowie VALUES(9999, 'TESTOWSKI', 0, sysdate, 5000,  10);





