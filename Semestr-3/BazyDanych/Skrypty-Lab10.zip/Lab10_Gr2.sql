
-- zad 2
select * from studenci;
drop table najnizsze_srednie;

create global temporary table Najnizsze_srednie
(kierunek varchar(150),
tryb varchar(30),
stopien number(1),
nr_indeksu number(6),
srednia number(3,2)
) on commit delete rows;


create global temporary table Najwyzsze_srednie
(kierunek varchar(150),
tryb varchar(30),
stopien number(1),
nr_indeksu number(6),
srednia number(3,2)
) on commit delete rows;

select * from (
select kierunek, tryb, stopien, min(srednia) 
min_srednia, max(srednia)max_srednia from studenci 
group by kierunek, tryb, stopien) t join studenci st 
using(kierunek, tryb, stopien);

insert all
when srednia= min_srednia then into najnizsze_srednie 
values (kierunek, tryb, stopien, nr_indeksu, srednia)
when srednia= max_srednia then into najwyzsze_srednie 
values (kierunek, tryb, stopien, nr_indeksu, srednia)
select * from (
select kierunek, tryb, stopien, min(srednia) 
min_srednia, max(srednia)max_srednia from studenci 
group by kierunek, tryb, stopien) t join studenci st 
using(kierunek, tryb, stopien);

select * from najnizsze_srednie;

commit;
drop table najnizsze_srednie;
drop table najwyzsze_srednie;

--Zad 3
create table zak(
id_studenta number(6) primary key,
nazwisko varchar(20) not null,
imie varchar(15) not null,
pseudonim varchar(30) not null,
kierunek varchar(20) default 'INFORMATYKA',
stopien number(1) check(stopien in (1,2,3)),
semestr number(1)check(semestr between 1 and 8)
);

create SEQUENCE zak_id_seq
start with 99985 
minvalue 10000
maxvalue 99999
increment by 10 
cycle ;


insert into zak values(Zak_id_seq.nextval, 'KOWALSKI', 'ROMAN', 'KOWAL',  'INFORMATYKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'NOWAK', 'ANNA', 'NOWA', 'INFORMATYKA',  1, 3);
insert into zak values(Zak_id_seq.nextval, 'PIECH', 'EWA', 'PEWA',  'MECHANIKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'POLAK', 'IZABELA', 'IZA',  'MECHANIKA', 2, 4);
select * from zak;
select zak_id_seq.currval from dual;

-- zad 4

alter sequence Zak_id_seq increment by 5;


--Zad 4 
insert into zak values(Zak_id_seq.nextval, 'WAWRZYNIEC', 'DAMIAN','WAWRZYN',  'INFORMATYKA',  2, 3);
insert into zak values(Zak_id_seq.nextval, 'KOSSAK', 'KATARZYNA', 'KOSA', 'INFORMATYKA',  1, 2);


select * from zak;

--Zad 5

create index imd_kier on zak(kierunek);
create index imd_stop on zak(stopien, semestr);
create unique index imd_pseud on zak(pseudonim);

insert into zak values((select max(id_studenta) from zak)+1, 'WAWRZYNIEC', 'JAN','WAWRZYN2',  'MATEMATYKA',  1, 2);
insert into zak values((select max(id_studenta) from zak)+1, 'WAWRZYNIEC', 'ADAM','WAWRZYNb2',  'MATEMATYKA',  1, 2);

drop index imd_kier;
drop table zak cascade constraints;

-- zad 6

create table studencibis as select * from studenci;
select * from studencibis;

create or replace view studentki as 
select * from studencibis where imiona like '%a'
order by nazwisko, imiona;

select * from studentki;

create or replace view zacy as 
select * from studencibis where imiona not like '%a'
order by nazwisko, imiona 
with read only;


--Zad 6
insert into Zacy values(123456, 'Testowski', 'Test', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Test', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Testa', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);

select * from studentki where nazwisko like 'Test%';
select * from zacy where nazwisko like 'Test%';
select * from studencibis where nazwisko like 'Test%';

--zad 8

create table pracownicybis as select * from pracownicy;

create or replace view lista_plac as 
select nr_akt, nazwisko, id_dzialu,
stanowisko, placa + placa * dod_staz * 1/100 + nvl(dod_funkcyjny, 0)
- nvl(koszt_ubezpieczenia, 0) pensja from pracownicybis 
where nr_akt >= 1000 and (data_zwol is null or data_zwol >= sysdate)
order by id_dzialu, nazwisko with check option;

select * from lista_plac;
INSERT INTO Lista_Plac VALUES(1222, 'TESTOWSKI', 10, 'INFORMATYK', 5000);

SELECT * FROM Lista_plac; 
select * from pracownicybis;


drop view lista_plac;
 
--Zad 9
create or replace view szefowie as
select nr_akt, nazwisko, liczba liczba_podwladnych, data_zatr, 
placa, id_dzialu from
(select przelozony, count(*) liczba from pracownicybis p1 
where data_zwol is null or data_zwol>=sysdate
group by przelozony) s1 join pracownicybis p2 on (p2.nr_akt=s1.przelozony)
where p2.data_zwol is null or p2.data_zwol>=sysdate;

delete from szefowie where nr_akt<=2000;
select * from szefowie;

INSERT INTO Szefowie VALUES(9999, 'TESTOWSKI', 0, sysdate, 5000,  10);

drop table pracownicybis;
drop view szefowie;
