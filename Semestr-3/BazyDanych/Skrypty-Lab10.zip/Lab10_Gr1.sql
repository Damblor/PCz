
--zad 1

CREATE GLOBAL TEMPORARY TABLE MIN_RYBY_WEDKARZY(
ID_WEDKARZA NUMBER(5),
NAZWISKO VARCHAR(30),
ID_GATUNKU NUMBER(2),
NAZWA VARCHAR(30),
WARTOSC NUMBER(5,2),
KOMENTARZ VARCHAR(30)
) 
ON COMMIT DELETE ROWS;

CREATE GLOBAL TEMPORARY TABLE MAX_RYBY_WEDKARZY(
ID_WEDKARZA NUMBER(5),
NAZWISKO VARCHAR(30),
ID_GATUNKU NUMBER(2),
NAZWA VARCHAR(30),
WARTOSC NUMBER(5,2),
KOMENTARZ VARCHAR(30)
) 
ON COMMIT DELETE ROWS;

SELECT * FROM REJESTRY;

SELECT ID_WEDKARZA,NAZWISKO,ID_GATUNKU,NAZWA,
(SELECT NVL(MIN(WAGA),0) FROM REJESTRY WHERE ID_WEDKARZA=WE.ID_WEDKARZA
AND ID_GATUNKU=ga.id_gatunku) NAJLZEJSZA,
(SELECT NVL(MAX(WAGA),0) FROM REJESTRY WHERE ID_WEDKARZA=WE.ID_WEDKARZA
AND ID_GATUNKU=ga.id_gatunku) NAJCIEZSZA
FROM WEDKARZE WE CROSS JOIN GATUNKI GA;

INSERT ALL 
INTO min_ryby_wedkarzy VALUES (ID_WEDKARZA,NAZWISKO,ID_GATUNKU,NAZWA,
NAJLZEJSZA,'NAJLZEJSZA')
INTO MAX_ryby_wedkarzy VALUES (ID_WEDKARZA,NAZWISKO,ID_GATUNKU,NAZWA,
NAJCIEZSZA,'NAJCIEZSZA')
SELECT ID_WEDKARZA,NAZWISKO,ID_GATUNKU,NAZWA,
(SELECT NVL(MIN(WAGA),0) FROM REJESTRY WHERE ID_WEDKARZA=WE.ID_WEDKARZA
AND ID_GATUNKU=ga.id_gatunku) NAJLZEJSZA,
(SELECT NVL(MAX(WAGA),0) FROM REJESTRY WHERE ID_WEDKARZA=WE.ID_WEDKARZA
AND ID_GATUNKU=ga.id_gatunku) NAJCIEZSZA
FROM WEDKARZE WE CROSS JOIN GATUNKI GA;

SELECT * FROM mAX_ryby_wedkarzy;
COMMIT;


CREATE GLOBAL TEMPORARY TABLE MIN_RYBY_WEDKARZY(
ID_WEDKARZA NUMBER(5),
NAZWISKO VARCHAR(30),
ID_GATUNKU NUMBER(2),
NAZWA VARCHAR(30),
WARTOSC NUMBER(5,2),
KOMENTARZ VARCHAR(30)
) 
ON COMMIT DELETE ROWS;

CREATE GLOBAL TEMPORARY TABLE MAX_RYBY_WEDKARZY(
ID_WEDKARZA NUMBER(5),
NAZWISKO VARCHAR(30),
ID_GATUNKU NUMBER(2),
NAZWA VARCHAR(30),
WARTOSC NUMBER(5,2),
KOMENTARZ VARCHAR(30)
) 
ON COMMIT DELETE ROWS;

SELECT * FROM REJESTRY;

--- w uj�ciu wagowym

SELECT ID_WEDKARZA,NAZWISKO,ID_GATUNKU,NAZWA,
(SELECT NVL(MIN(WAGA),0) FROM REJESTRY WHERE ID_WEDKARZA=WE.ID_WEDKARZA
AND ID_GATUNKU=ga.id_gatunku) NAJLZEJSZA,
(SELECT NVL(MAX(WAGA),0) FROM REJESTRY WHERE ID_WEDKARZA=WE.ID_WEDKARZA
AND ID_GATUNKU=ga.id_gatunku) NAJCIEZSZA
FROM WEDKARZE WE CROSS JOIN GATUNKI GA;

INSERT ALL 
WHEN NAJLZEJSZA>0 AND NAJLZEJSZA<1 THEN INTO min_ryby_wedkarzy VALUES (ID_WEDKARZA,NAZWISKO,ID_GATUNKU,NAZWA,
NAJLZEJSZA,'NAJLZEJSZA')
WHEN  NAJCIEZSZA>=4 THEN
INTO MAX_ryby_wedkarzy VALUES (ID_WEDKARZA,NAZWISKO,ID_GATUNKU,NAZWA,
NAJCIEZSZA,'NAJCIEZSZA')
SELECT ID_WEDKARZA,NAZWISKO,ID_GATUNKU,NAZWA,
(SELECT NVL(MIN(WAGA),0) FROM REJESTRY WHERE ID_WEDKARZA=WE.ID_WEDKARZA
AND ID_GATUNKU=ga.id_gatunku) NAJLZEJSZA,
(SELECT NVL(MAX(WAGA),0) FROM REJESTRY WHERE ID_WEDKARZA=WE.ID_WEDKARZA
AND ID_GATUNKU=ga.id_gatunku) NAJCIEZSZA
FROM WEDKARZE WE CROSS JOIN GATUNKI GA;

SELECT * FROM min_ryby_wedkarzy;

DROP TABLE  min_ryby_wedkarzy CASCADE CONSTRAINTS;

DROP TABLE  mAX_ryby_wedkarzy CASCADE CONSTRAINTS;


--Zad 3
create table zak(
id_studenta number(6) primary key,
nazwisko varchar(20) not null,
imie varchar (15) not null,
pseudonim varchar(30) not null,
kierunek varchar(20) default 'INFORMATYKA',
stopien number(1) check(stopien in(1,2,3)),
semestr number(1) check(semestr between 1 and 8)
);

create sequence zak_id_seq 
start with 99985
minvalue 10000
maxvalue 99999
increment by 10
cycle;


insert into zak values(Zak_id_seq.nextval, 'KOWALSKI', 'ROMAN', 'KOWAL',  'INFORMATYKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'NOWAK', 'ANNA', 'NOWA', 'INFORMATYKA',  1, 3);
insert into zak values(Zak_id_seq.nextval, 'PIECH', 'EWA', 'PEWA',  'MECHANIKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'POLAK', 'IZABELA', 'IZA',  'MECHANIKA', 2, 4);

select * from zak;

select  Zak_id_seq.currval  from dual;


--Zad 4 
alter sequence Zak_id_seq increment by 5;



insert into zak values(Zak_id_seq.nextval, 'WAWRZYNIEC', 'DAMIAN','WAWRZYN',  'INFORMATYKA',  2, 3);
insert into zak values(Zak_id_seq.nextval, 'KOSSAK', 'KATARZYNA', 'KOSA', 'INFORMATYKA',  1, 2);
select * from zak;

--Zad 5
create index ind_kierunek ON zak(kierunek);
create index ind_stopien_semestr on zak(stopien, semestr);
create unique index un_ind_pseudonim on zak(pseudonim);

insert into zak values((select max(id_studenta) from zak)+1,
'WAWRZYNIEC', 'JAN','WAWRZYN2',  'MATEMATYKA',  1, 2);
insert into zak values((select max(id_studenta) from zak)+1,
'WAWRZYNIEC', 'ADAM','WAWRZYN3',  'MATEMATYKA',  1, 2);

--zad6
create table studenci_bis as select * from studenci;
select * from studenci_bis;
create or replace view studentki as select * from studenci_bis 
where imiona like '%a' order by nazwisko,imiona;
drop view studenci;
select * from studentki;

create or replace view zacy as select * from studenci_bis 
where imiona not like '%a' order by nazwisko,imiona with read only;
select * from zacy;




--Zad 6
insert into Zacy values(123457, 'Testowski', 'Test', 
to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123457, 'Testowski', 'Test', 
to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Testa', 
to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);

select * from studentki where nazwisko like 'Test%';
select * from zacy where nazwisko like 'Test%';
select * from studencibis where nazwisko like 'Test%';

drop table studenci_bis cascade constraints;

-- 


--zad 7
insert into S1R1 values(12345, 'RAKOWSKI', 'TOMASZ', 1, 'RT12345');

--zad 8
INSERT INTO Lista_Plac VALUES(1222, 'TESTOWSKI', 10, 'INFORMATYK', 5000);

SELECT * FROM Lista_plac; 
select * from pracownicybis;
 
--Zad 9
INSERT INTO Szefowie VALUES(9999, 'TESTOWSKI', 0, sysdate, 5000,  10);