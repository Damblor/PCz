
-- Zad 2
create global temporary table najnizsze_srednie
(
    kierunek varchar2(150),
    tryb varchar2(30),
    stopien number(1),
    nr_indeksu number(6),
    srednia number(3,2)
) on commit delete rows;

create global temporary table najwyzsze_srednie
(
    kierunek varchar2(150),
    tryb varchar2(30),
    stopien number(1),
    nr_indeksu number(6),
    srednia number(3,2)
) on commit delete rows;

create global temporary table inne_srednie
(
    kierunek varchar2(150),
    tryb varchar2(30),
    stopien number(1),
    nr_indeksu number(6),
    srednia number(3,2)
) on commit delete rows;

select * from
(select kierunek, tryb, stopien, min(srednia) min_sr, max(srednia) max_sr from studenci
group by kierunek, tryb, stopien) join studenci using(kierunek,tryb,stopien);

insert all
when srednia=min_sr then into najnizsze_srednie values(kierunek,tryb,stopien,nr_indeksu,min_sr)
when srednia=max_sr then into najwyzsze_srednie values(kierunek,tryb,stopien,nr_indeksu,max_sr)
else into najnizsze_srednie values(kierunek,tryb,stopien,nr_indeksu,srednia)
select * from
(select kierunek, tryb, stopien, min(srednia) min_sr, max(srednia) max_sr from studenci
group by kierunek, tryb, stopien) join studenci using(kierunek,tryb,stopien);
commit;
select * from najwyzsze_srednie;
select * from najnizsze_srednie;

drop table najnizsze_srednie;
drop table najwyzsze_srednie;
drop table inne_srednie;

-- zad 3

CREATE TABLE ZAK
(
    Id_studenta NUMBER(6) PRIMARY KEY,
    Nazwisko VARCHAR(20),
    Imie VARCHAR(15),
    Pseudonim VARCHAR(30),
    Kierunek VARCHAR(20),
    Stopien NUMBER(1),
    Semestr NUMBER(1)
);

CREATE SEQUENCE Zak_id_seq
START WITH 99985
MINVALUE 10000
MAXVALUE 99999
INCREMENT BY 10
CYCLE;

--Zad 3

insert into zak values(Zak_id_seq.nextval, 'KOWALSKI', 'ROMAN', 'KOWAL',  'INFORMATYKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'NOWAK', 'ANNA', 'NOWA', 'INFORMATYKA',  1, 3);
insert into zak values(Zak_id_seq.nextval, 'PIECH', 'EWA', 'PEWA',  'MECHANIKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'POLAK', 'IZABELA', 'IZA',  'MECHANIKA', 2, 4);

SELECT * FROM Zak;
SELECT zak_id_seq.currval FROM DUAL;

--Zad 4 
alter SEQUENCE Zak_id_seq INCREMENT by 5;

insert into zak values(Zak_id_seq.nextval, 'WAWRZYNIEC', 'DAMIAN','WAWRZYN',  'INFORMATYKA',  2, 3);
insert into zak values(Zak_id_seq.nextval, 'KOSSAK', 'KATARZYNA', 'KOSA', 'INFORMATYKA',  1, 2);

select * from zak;
--Zad 5
create index ind_kier on zak(kierunek);
create index ind_ss on zak(stopien, semestr);
create unique index ind_ps on zak(pseudonim);

insert into zak values((select max(id_studenta) from zak)+1, 'WAWRZYNIEC', 'JAN','WAWRZYN2',  'MATEMATYKA',  1, 2);
insert into zak values((select max(id_studenta) from zak)+1, 'WAWRZYNIEC', 'ADAM','WAWRZYN1',  'MATEMATYKA',  1, 2);

drop index ind_ps;
drop table zak cascade CONSTRAINTS;

--Zad 6

create table StudenciBis as select * from Studenci;
select*from StudenciBis;

create or replace VIEW Studentki as select*from StudenciBis
where imiona like '%a' order by nazwisko, imiona;
select*from Studentki;

create or replace VIEW Zacy as select*from StudenciBis
where imiona not like '%a' order by nazwisko, imiona
with read only;


insert into Zacy values(123456, 'Testowski', 'Test', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Test', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Testa', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);

select * from studentki where nazwisko like 'Test%';
select * from zacy where nazwisko like 'Test%';
select * from studencibis where nazwisko like 'Test%';

--zad 7
create or replace VIEW S1R1 as select nr_indeksu, nazwisko, imiona, rok,
substr(nazwisko,1,1) || substr(imiona,1,1) ||  nr_indeksu as pseudonim from Zacy
where stopien = 1 and rok = 1 WITH CHECK OPTION;

select * from S1R1;

insert into S1R1 values(12345, 'RAKOWSKI', 'TOMASZ', 1, 'RT12345');

delete from Studentki where nr_indeksu > 114000;

select * from StudenciBis where nr_indeksu > 114000;

drop table StudenciBis;

drop view S1R1;
drop view Studentki;
drop view Zacy;


--zad 8
CREATE TABLE PracownicyBis AS SELECT * FROM Pracownicy;
CREATE OR REPLACE VIEW lista_plac AS
SELECT nr_akt, nazwisko, id_dzialu, stanowisko,
    placa + dod_staz * placa * 0.01 + NVL(dod_funkcyjny, 0) - NVL(koszt_ubezpieczenia, 0) pensja
 FROM PracownicyBis
 WHERE nr_akt >= 1000 --AND (data_zwol IS NULL OR data_zwol >= sysdate)
 ORDER BY id_dzialu, nazwisko
 WITH CHECK OPTION;

INSERT INTO Lista_Plac VALUES(1222, 'TESTOWSKI', 10, 'INFORMATYK', 5000);
DROP TABLE PracownicyBis;
DROP VIEW lista_plac;

SELECT * FROM Lista_plac; 
select * from pracownicybis;
 
--Zad 9
INSERT INTO Szefowie VALUES(9999, 'TESTOWSKI', 0, sysdate, 5000,  10);