--zad 1
create global temporary table max_ryby_wedkarzy (
id_wedkarza number(5),
nazwisko varchar2(30),
id_gatunku number(2), 
nazwa varchar(30),
wartosc number(5,2),
komentarz varchar2(30) 
) on commit delete rows;  

create global temporary table min_ryby_wedkarzy (
id_wedkarza number(5),
nazwisko varchar2(30),
id_gatunku number(2), 
nazwa varchar(30),
wartosc number(5,2),
komentarz varchar2(30) 
) on commit delete rows;  

select id_wedkarza wedk, nazwisko naz, id_gatunku gat, nazwa,
( select nvl(min(waga), 0) from rejestry 
where id_wedkarza = w1.id_wedkarza and id_gatunku = g1.id_gatunku) najlzejsza,
( select nvl(max(waga), 0) from rejestry 
where id_wedkarza = w1.id_wedkarza and id_gatunku = g1.id_gatunku) najciezsza
from wedkarze w1 cross join gatunki g1; 

insert all 
into min_ryby_wedkarzy 
values ( wedk, naz, gat, nazwa, najlzejsza, 'najlzesza ryba' ) 
into max_ryby_wedkarzy 
values ( wedk, naz, gat, nazwa, najciezsza, 'najciezsza ryba' ) 
select id_wedkarza wedk, nazwisko naz, id_gatunku gat, nazwa,
( select nvl(min(waga), 0) from rejestry 
where id_wedkarza = w1.id_wedkarza and id_gatunku = g1.id_gatunku) najlzejsza,
( select nvl(max(waga), 0) from rejestry 
where id_wedkarza = w1.id_wedkarza and id_gatunku = g1.id_gatunku) najciezsza
from wedkarze w1 cross join gatunki g1 ;

select * from min_ryby_wedkarzy; 

commit; 

select id_wedkarza wedk, nazwisko naz, id_gatunku gat, nazwa,
( select nvl(min(dlugosc), 0) from rejestry 
where id_wedkarza = w1.id_wedkarza and id_gatunku = g1.id_gatunku) najkrotsza,
( select nvl(max(dlugosc), 0) from rejestry 
where id_wedkarza = w1.id_wedkarza and id_gatunku = g1.id_gatunku) najdluzsza
from wedkarze w1 cross join gatunki g1; 

insert all 
when najkrotsza > 0 and  najkrotsza < 35 
then
into min_ryby_wedkarzy 
values ( wedk, naz, gat, nazwa, najkrotsza, 'najkrotsza ryba' )
when najdluzsza > 60 then
into max_ryby_wedkarzy 
values ( wedk, naz, gat, nazwa, najdluzsza, 'najdluzsza ryba' ) 
select id_wedkarza wedk, nazwisko naz, id_gatunku gat, nazwa,
( select nvl(min(dlugosc), 0) from rejestry 
where id_wedkarza = w1.id_wedkarza and id_gatunku = g1.id_gatunku) najkrotsza,
( select nvl(max(dlugosc), 0) from rejestry 
where id_wedkarza = w1.id_wedkarza and id_gatunku = g1.id_gatunku) najdluzsza
from wedkarze w1 cross join gatunki g1; 

select * from max_ryby_wedkarzy; 

commit; 

drop table min_ryby_wedkarzy; 
drop table max_ryby_wedkarzy;

-- zad 3
create table Zak(
id_studenta number(6) primary key,
nazwisko varchar(20) not null,
imie varchar(15) not null,
pseudonim varchar(30) not null,
kierunek varchar(20) default 'INFORMATYKA',
stopien number(1) check (stopien in (1,2,3) ),
semestr number(1) check (semestr between 1 and 8)
);
create sequence  Zak_id_seq 
start with 99985
minvalue 10000
maxvalue 99999
increment by 10
cycle;




insert into zak values(Zak_id_seq.nextval, 'KOWALSKI', 'ROMAN', 'KOWAL',  'INFORMATYKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'NOWAK', 'ANNA', 'NOWA', 'INFORMATYKA',  1, 3);
insert into zak values(Zak_id_seq.nextval, 'PIECH', 'EWA', 'PEWA',  'MECHANIKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'POLAK', 'IZABELA', 'IZA',  'MECHANIKA', 2, 4);
select* from zak;
select Zak_id_seq.currval from dual;

--Zad 4 
alter sequence Zak_id_seq increment by 5;

insert into zak values(Zak_id_seq.nextval, 'WAWRZYNIEC', 'DAMIAN',
'WAWRZYN',  'INFORMATYKA',  2, 3);
insert into zak values(Zak_id_seq.nextval, 'KOSSAK', 'KATARZYNA', 
'KOSA', 'INFORMATYKA',  1, 2);

select * from zak;

--Zad 5
create index ind_kierunek on zak(kierunek);
create index ind_stopien on zak(stopien, semestr);
create unique index ind_pseudonim on zak(pseudonim);

drop index ind_stopien;

insert into zak values((select max(id_studenta) from zak)+1, 'WAWRZYNIEC', 
'JAN','WAWRZYN2',  'MATEMATYKA',  1, 2);
insert into zak values((select max(id_studenta) from zak)+1, 'WAWRZYNIEC', 
'ADAM','WAWRZYN3',  'MATEMATYKA',  1, 2);

drop table zak cascade constraints;

--Zad 6
create table StudenciBis as select * from studenci;
select * from StudenciBis;
create or replace view Studentki as 
select * from StudenciBis where imiona like '%a' order by nazwisko, imiona; 
select * from Studentki;
create or replace view Zacy as 
select * from StudenciBis 
where imiona not like '%a' order by nazwisko, imiona
with read only;
select * from Zacy;


insert into Zacy values(123456, 'Testowski', 'Test', 
  to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Test', 
  to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Testa', 
  to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);


select * from Studentki where nazwisko like 'Test%';
select * from Zacy where nazwisko like 'Test%';
select * from studencibis where nazwisko like 'Test%';

--zad 7

create or replace view s1r1 as
select nr_indeksu, nazwisko, imiona, rok,substr(imiona,1,1)||
substr(nazwisko, 1,1)||nr_indeksu pseudonim from studencibis
where stopien = 1 and rok = 1
with check option
;
insert into S1R1 values(12345, 'RAKOWSKI', 'TOMASZ', 1, 'RT12345');

drop table studencibis;
drop view s1r1;
drop view studentki;
drop view zacy;


--zad 8
create table pracownicybis as select *from pracownicy; 
create or replace view lista_plac as 
select nr_akt, nazwisko,id_dzialu,stanowisko,
placa+placa*dod_staz*0.01+NVL(dod_funkcyjny,0)-NVL(koszt_ubezpieczenia,0) pensja
from pracownicybis where nr_akt>=1000 ORDER by id_dzialu,nazwisko with check
option;
select * from pracownicy;

INSERT INTO Lista_Plac VALUES(1222, 'TESTOWSKI', 10, 'INFORMATYK', 5000);

SELECT * FROM Lista_plac; 
select * from pracownicybis;
 
--Zad 9
INSERT INTO Szefowie VALUES(9999, 'TESTOWSKI', 0, sysdate, 5000,  10);

