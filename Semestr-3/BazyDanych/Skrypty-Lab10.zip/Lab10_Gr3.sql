--zad 2
create global temporary table najnizsze_srednie(
kierunek varchar(150),
tryb varchar (30),
stopien number(1),
nr_indeksu number(6),
srednia number (3,2)
)on commit delete rows;

create global temporary table najwyzsze_srednie(
kierunek varchar(150),
tryb varchar (30),
stopien number(1),
nr_indeksu number(6),
srednia number (3,2)
)on commit delete rows;

create global temporary table wybrane_srednie(
kierunek varchar(150),
tryb varchar (30),
stopien number(1),
nr_indeksu number(6),
srednia number (3,2)
)on commit delete rows;
select* from 
(select kierunek, tryb, stopien ,min(srednia) najnizsza,max(srednia)najwyzsza
from studenci 
group by kierunek, tryb, stopien)
join studenci using (kierunek, tryb, stopien);

insert all 
when srednia = najnizsza then into najnizsze_srednie
values (kierunek,tryb,stopien,nr_indeksu,srednia)
when srednia = najwyzsza then into najwyzsze_srednie
values (kierunek,tryb,stopien,nr_indeksu,srednia)
when srednia between najnizsza + (najwyzsza - najnizsza)*0.25
and najnizsza + (najwyzsza - najnizsza)*0.75 then into wybrane_srednie
values (kierunek,tryb,stopien,nr_indeksu,srednia)select* from 
(select kierunek, tryb, stopien ,min(srednia) najnizsza,max(srednia)najwyzsza
from studenci 
group by kierunek, tryb, stopien)
join studenci using (kierunek, tryb, stopien);

select * from najwyzsze_srednie;
commit ;
drop table najwyzsze_srednie;
drop table najnizsze_srednie;
drop table wybrane_srednie;

-- zad 3
create table zak(
id_studenta number(6) primary key,
nazwisko varchar(20),
imie varchar (15),
pseudonim varchar (30),
kierunek varchar(20),
stopien number(1),
semestr number(1)
);

create sequence zak_id_seq 
start with 99985
minvalue 10000
maxvalue 99999
increment by 10
cycle ;


insert into zak values(Zak_id_seq.nextval, 'KOWALSKI', 'ROMAN', 'KOWAL',  'INFORMATYKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'NOWAK', 'ANNA', 'NOWA', 'INFORMATYKA',  1, 3);
insert into zak values(Zak_id_seq.nextval, 'PIECH', 'EWA', 'PEWA',  'MECHANIKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'POLAK', 'IZABELA', 'IZA',  'MECHANIKA', 2, 4);


select * from zak;

--Zad 4 
alter sequence Zak_id_seq increment by 7;
insert into zak values(Zak_id_seq.nextval, 'WAWRZYNIEC', 'DAMIAN','WAWRZYN',  'INFORMATYKA',  2, 3);
insert into zak values(Zak_id_seq.nextval, 'KOSSAK', 'KATARZYNA', 'KOSA', 'INFORMATYKA',  1, 2);
 select * from Zak;
 select Zak_id_seq.currval from dual; 


--Zad 5
create index imd_kier on Zak(kierunek);
create index imd_stop on Zak(stopien, semestr);
create unique index imd_pseu on Zak(pseudonim);
insert into zak values((select max(id_studenta) 
from zak)+1, 'WAWRZYNIEC', 'JAN','WAWRZYN2',  'MATEMATYKA',  1, 2);
insert into zak values((select max(id_studenta) 
from zak)+1, 'WAWRZYNIEC', 'ADAM','WAWRZYN2',  'MATEMATYKA',  1, 2);
drop index imd_kier;
drop table Zak cascade constraints;

-- zad 6
create table studencibis as select * from studenci;
create or replace view studentki as select * from studencibis 
where imiona like '%a' order by nazwisko, imiona;

select * from studentki;


create or replace view zacy as select * from studencibis 
where imiona not like '%a' order by nazwisko, imiona with read only;

select * from zacy;
--Zad 6
insert into Zacy values(123456, 'Testowski', 'Test', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Test', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Testa', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);

select * from studentki where nazwisko like 'Test%';
select * from zacy where nazwisko like 'Test%';
select * from studencibis where nazwisko like 'Test%';



--zad 7
create or replace view S1R1 as select nr_indeksu,nazwisko,imiona,rok,stopien,
substr(imiona,1,1)||substr(nazwisko,1,1)||nr_indeksu pseudonim from zacy 
where stopien=1 and rok=1 with check option;
select * from S1R1;


insert into S1R1 values(12345, 'RAKOWSKI', 'TOMASZ', 1,1, 'TR12345');
drop table studencibis;
drop view S1R1;
drop view studentki;
drop view zacy;


--zad 8
INSERT INTO Lista_Plac VALUES(1222, 'TESTOWSKI', 10, 'INFORMATYK', 5000);

SELECT * FROM Lista_plac; 
select * from pracownicybis;
 
--Zad 9
INSERT INTO Szefowie VALUES(9999, 'TESTOWSKI', 0, sysdate, 5000,  10);
