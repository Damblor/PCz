--zad 1
create global temporary table Min_Ryby_Wedkarzy(
id_wedkarza number (5),
nazwisko varchar(30),
id_gatunku number(2),
nazwa varchar (30),
wartosc number(5,2),
komentarz varchar (30)
) on commit delete rows ;
create global temporary table Max_Ryby_Wedkarzy(
id_wedkarza number (5),
nazwisko varchar(30),
id_gatunku number(2),
nazwa varchar (30),
wartosc number(5,2),
komentarz varchar (30)
) on commit delete rows ;

create global temporary table Tabela(
id_wedkarza number (5),
nazwisko varchar(30),
id_gatunku number(2),
nazwa varchar (30),
wartosc number(5,2),
komentarz varchar (30)
) on commit delete rows ;

select id_wedkarza, nazwisko, id_gatunku, nazwa, 
(select nvl(min (waga), 0) from rejestry where id_wedkarza =T1.id_wedkarza and
id_gatunku=T2.id_gatunku) min_wag, 
(select nvl(max (waga), 0) from rejestry where id_wedkarza =T1.id_wedkarza and
id_gatunku=T2.id_gatunku) max_wag
from wedkarze T1 cross join gatunki T2;

insert all 
into min_ryby_wedkarzy values (id_wedkarza, nazwisko, id_gatunku, nazwa, min_wag, 'najlzejsza')
into max_ryby_wedkarzy values (id_wedkarza, nazwisko, id_gatunku, nazwa, max_wag, 'najciezsza')
into tabela values (id_wedkarza, nazwisko, id_gatunku, nazwa, (min_wag+max_wag)/2, 'srednia')
select id_wedkarza, nazwisko, id_gatunku, nazwa, 
(select nvl(min (waga), 0) from rejestry where id_wedkarza =T1.id_wedkarza and
id_gatunku=T2.id_gatunku) min_wag, 
(select nvl(max (waga), 0) from rejestry where id_wedkarza =T1.id_wedkarza and
id_gatunku=T2.id_gatunku) max_wag
from wedkarze T1 cross join gatunki T2;

select* from max_ryby_wedkarzy;
commit;

select id_wedkarza, nazwisko, id_gatunku, nazwa, 
(select nvl(min (waga), 0) from rejestry where id_wedkarza =T1.id_wedkarza and
id_gatunku=T2.id_gatunku) min_wag, 
(select nvl(max (waga), 0) from rejestry where id_wedkarza =T1.id_wedkarza and
id_gatunku=T2.id_gatunku) max_wag
from wedkarze T1 cross join gatunki T2;

insert all 
when min_dlg>0 and min_dlg<35 then 
into min_ryby_wedkarzy values (id_wedkarza, nazwisko, id_gatunku, nazwa, min_dlg, 'najkrotsza')
when max_dlg>60 then
into max_ryby_wedkarzy values (id_wedkarza, nazwisko, id_gatunku, nazwa, max_dlg, 'najdluzsza')
else
into tabela values (id_wedkarza, nazwisko, id_gatunku, nazwa, (min_dlg+max_dlg)/2, 'pozostale')
select id_wedkarza, nazwisko, id_gatunku, nazwa, 
(select nvl(min (dlugosc), 0) from rejestry where id_wedkarza =T1.id_wedkarza and
id_gatunku=T2.id_gatunku) min_dlg, 
(select nvl(max (dlugosc), 0) from rejestry where id_wedkarza =T1.id_wedkarza and
id_gatunku=T2.id_gatunku) max_dlg
from wedkarze T1 cross join gatunki T2;
select* from max_ryby_wedkarzy;
select* from tabela;
drop TABLE min_ryby_wedkarzy;
drop TABLE max_ryby_wedkarzy;
drop TABLE  tabela;

--Zad 3

create table Zak(
id_studenta NUMBER(6) primary key,
nazwisko VARCHAR(20),
imie VARCHAR(15),
pseudonim VARCHAR(30),
kierunek VARCHAR(20),
stopien NUMBER(1) check (stopien in (1,2,3)),
semestr NUMBER(1));


create sequence Zak_id_seq 
start with 99985
MINVALUE 10000
MAXVALUE 99999
increment by 10
cycle;




insert into zak values(Zak_id_seq.nextval, 'KOWALSKI', 'ROMAN', 'KOWAL',  'INFORMATYKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'NOWAK', 'ANNA', 'NOWA', 'INFORMATYKA',  1, 3);
insert into zak values(Zak_id_seq.nextval, 'PIECH', 'EWA', 'PEWA',  'MECHANIKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'POLAK', 'IZABELA', 'IZA',  'MECHANIKA', 2, 4);

select * from Zak;
select Zak_id_seq.currval from dual;

--Zad 4 
alter sequence Zak_id_seq increment by 4;

insert into zak values(Zak_id_seq.nextval, 'WAWRZYNIEC', 'DAMIAN','WAWRZYN',  'INFORMATYKA',  2, 3);
insert into zak values(Zak_id_seq.nextval, 'KOSSAK', 'KATARZYNA', 'KOSA', 'INFORMATYKA',  1, 2);

select * from zak;

--Zad 5
create index kier on Zak(kierunek);
create index st on Zak(stopien, semestr);
create unique INDEX pseud on Zak(pseudonim);

insert into zak values((select max(id_studenta) from zak)+1, 'WAWRZYNIEC', 'JAN','WAWRZYN2',  'MATEMATYKA',  1, 2);
insert into zak values((select max(id_studenta) from zak)+1, 'WAWRZYNIEC', 'ADAM','WAWRZYN3',  'MATEMATYKA',  1, 2);

drop index kier;
drop table Zak cascade constraints;

--Zad 6
create table studenciBis as select * from studenci;
select * from studencibis;

create or replace view studentki as select * from studencibis where
imiona like '%a' order by nazwisko,imiona;

select * from studentki;

create or replace view zacy as select * from studencibis where
imiona not like '%a' order by nazwisko,imiona with read only;

select * from zacy;





insert into Zacy values(123456, 'Testowski', 'Test', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Test', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Testa', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);

select * from studentki where nazwisko like 'Test%';
select * from zacy where nazwisko like 'Test%';
select * from studencibis where nazwisko like 'Test%';

--zad 7
create or replace view S1R1 as select nr_indeksu, nazwisko, imiona, rok, substr(nazwisko, 1,1) | |
substr(imiona, 1,1) | | nr_indeksu pseudonim 
from zacy where stopien = 1 and rok = 1 with check option;


insert into S1R1 values(12345, 'RAKOWSKI', 'TOMASZ', 1, 'RT12345');

select * from s1r1;

delete from studentki where nr_indeksu between 114000 and 115000;

select* from studencibis where nr_indeksu between 114000 and 115000;

commit;
drop table studencibis;

drop view zacy;

--zad 8
INSERT INTO Lista_Plac VALUES(1222, 'TESTOWSKI', 10, 'INFORMATYK', 5000);

SELECT * FROM Lista_plac; 
select * from pracownicybis;
 
--Zad 9
INSERT INTO Szefowie VALUES(9999, 'TESTOWSKI', 0, sysdate, 5000,  10);

