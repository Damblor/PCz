-- zad 1

CREATE GLOBAL TEMPORARY TABLE Min_Ryby_Wedkarzy
(
id_wedkarza number(5),
nazwisko varchar(30),
id_gatunku number(2),
nazwa varchar(30),
wartosc number(5,2),
komentarz varchar(30)
)
ON COMMIT DELETE ROWS;

CREATE GLOBAL TEMPORARY TABLE Max_Ryby_Wedkarzy
(
id_wedkarza number(5),
nazwisko varchar(30),
id_gatunku number(2),
nazwa varchar(30),
wartosc number(5,2),
komentarz varchar(30)
)
ON COMMIT DELETE ROWS;

SELECT id_wedkarza wed, nazwisko naz, id_gatunku gat, nazwa,
(
SELECT NVL(MIN(waga), 0) FROM rejestry
WHERE T2.id_wedkarza=id_wedkarza AND T1.id_gatunku=id_gatunku 
) najlzejsza,
(
SELECT NVL(MAX(waga), 0) FROM rejestry
WHERE T2.id_wedkarza=id_wedkarza AND T1.id_gatunku=id_gatunku 
) najciezsza
FROM gatunki T1 CROSS JOIN wedkarze T2;

INSERT ALL
INTO min_ryby_wedkarzy VALUES (wed, naz, gat, nazwa, najlzejsza, 'najlzejsza ryba')
INTO max_ryby_wedkarzy VALUES (wed, naz, gat, nazwa, najciezsza, 'najciezsza ryba')
SELECT id_wedkarza wed, nazwisko naz, id_gatunku gat, nazwa,
(
SELECT NVL(MIN(waga), 0) FROM rejestry
WHERE T2.id_wedkarza=id_wedkarza AND T1.id_gatunku=id_gatunku 
) najlzejsza,
(
SELECT NVL(MAX(waga), 0) FROM rejestry
WHERE T2.id_wedkarza=id_wedkarza AND T1.id_gatunku=id_gatunku 
) najciezsza
FROM gatunki T1 CROSS JOIN wedkarze T2;

SELECT * FROM max_ryby_wedkarzy;

COMMIT;

INSERT ALL
WHEN najkrotsza>0 AND najkrotsza<35 THEN
INTO min_ryby_wedkarzy VALUES (wed, naz, gat, nazwa, najkrotsza, 'najkrotsza ryba')
WHEN najdluzsza>60 THEN
INTO max_ryby_wedkarzy VALUES (wed, naz, gat, nazwa, najdluzsza, 'najdluzsza ryba')
SELECT id_wedkarza wed, nazwisko naz, id_gatunku gat, nazwa,
(
SELECT NVL(MIN(dlugosc), 0) FROM rejestry
WHERE T2.id_wedkarza=id_wedkarza AND T1.id_gatunku=id_gatunku 
) najkrotsza,
(
SELECT NVL(MAX(dlugosc), 0) FROM rejestry
WHERE T2.id_wedkarza=id_wedkarza AND T1.id_gatunku=id_gatunku 
) najdluzsza
FROM gatunki T1 CROSS JOIN wedkarze T2;

SELECT * FROM min_ryby_wedkarzy;

COMMIT;

DROP TABLE min_ryby_wedkarzy;
DROP TABLE max_ryby_wedkarzy;

-- zad 3
create table Zak
(
id_studenta number(6) primary key,
nazwisko VARCHAR(20) not null,
imie VARCHAR(15) not null,
pseudonim VARCHAR(30) not null,
kierunek VARCHAR(20) DEFAULT 'INFORMATYKA',
stopien number(1) check(stopien in(1,2,3)),
semestr number(1) check(semestr BETWEEN 1 and 8)
);
create SEQUENCE Zak_id_seq 
START with 99985
MINVALUE 10000
MAXVALUE 99999
INCREMENT by 10
CYCLE;


insert into zak values(Zak_id_seq.nextval, 'KOWALSKI', 'ROMAN', 'KOWAL',  'INFORMATYKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'NOWAK', 'ANNA', 'NOWA', 'INFORMATYKA',  1, 3);
insert into zak values(Zak_id_seq.nextval, 'PIECH', 'EWA', 'PEWA',  'MECHANIKA', 1, 2);
insert into zak values(Zak_id_seq.nextval, 'POLAK', 'IZABELA', 'IZA',  'MECHANIKA', 2, 4);

select * from zak;
select Zak_id_seq.currval from dual;

-- zad 4 

alter sequence Zak_id_seq increment by 6;


insert into zak values(Zak_id_seq.nextval, 'WAWRZYNIEC', 'DAMIAN','WAWRZYN',
  'INFORMATYKA',  2, 3);
insert into zak values(Zak_id_seq.nextval, 'KOSSAK', 'KATARZYNA', 'KOSA',
  'INFORMATYKA',  1, 2);

select * from Zak;

--Zad 5
create index ind_kier on Zak(kierunek);
create index ind_st_sem on Zak(stopien, semestr);
create unique index ind_pseud on Zak(pseudonim);

insert into zak values((select max(id_studenta) from zak)+1, 
'WAWRZYNIEC', 'JAN','WAWRZYN2',  'MATEMATYKA',  1, 2);

insert into zak values((select max(id_studenta) from zak)+1, 
'WAWRZYNIEC', 'ADAM','WAWRZYN21',  'MATEMATYKA',  1, 2);

drop index ind_st_sem; 
drop table Zak cascade constraints;

--Zad 6
create table StudenciBis as SELECT * FROM studenci;
create or replace view Studentki as 
select * from StudenciBis where imiona like '%a' order by nazwisko, imiona;
select * from studentki;

create or replace view Zacy as 
select * from StudenciBis where imiona not like '%a' order by nazwisko, imiona
with read only;


insert into Zacy values(123456, 'Testowski', 'Test', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Test', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);
insert into Studentki values(123456, 'Testowski', 'Testa', to_date('01-01-1995', 'dd-mm-yyyy'), 'adres', 'kierunek', 'tryb', 1, 1, 'specjalnosc', 1, 4);

select * from studentki where nazwisko like 'Test%';
select * from zacy where nazwisko like 'Test%';
select * from studencibis where nazwisko like 'Test%';

-- zad 7
create or replace view s1r1 as select nr_indeksu,nazwisko,imiona,rok,
substr(imiona,1,1)||substr(nazwisko,1,1)||nr_indeksu pseudonim from zacy where
stopien=1 and rok=1 with check option;
select * from s1r1;

--zad 7
insert into S1R1 values(12345, 'RAKOWSKI', 'TOMASZ', 1, 'RT12345');

--zad 8
create table PracownicyBis as select * from pracownicy;
create or replace view lista_plac as 
select nr_akt, nazwisko, id_dzialu, stanowisko, placa+placa*dod_staz*0.01+
nvl(dod_funkcyjny,0)-nvl(koszt_ubezpieczenia,0) pensja from pracownicy where 
nr_akt>=1000 and (data_zwol is null or data_zwol>=sysdate) order by id_dzialu,
nazwisko with check option;


INSERT INTO Lista_Plac VALUES(1222, 'TESTOWSKI', 10, 'INFORMATYK', 5000);

SELECT * FROM Lista_plac; 
select * from pracownicybis;
 
--Zad 9
INSERT INTO Szefowie VALUES(9999, 'TESTOWSKI', 0, sysdate, 5000,  10);




