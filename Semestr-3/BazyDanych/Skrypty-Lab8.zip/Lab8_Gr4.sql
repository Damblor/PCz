
-- zad 1
create table Zawodnicy
(
    id_zawodnika NUMBER(4) constraint id_zaw_PK primary key,
    nazwisko VARCHAR(30) constraint nazw_zaw NOT NULL,
    imie VARCHAR(30) constraint imie_zaw NOT NULL,
    data_ur DATE constraint data_chk CHECK(extract(year from data_ur) >= 1940),
    wzrost NUMBER(3) constraint wzr_chk CHECK(wzrost between 100 and 220),
    waga NUMBER(4,1) constraint waga_chk CHECK (waga between 15 and 150),
    pozycja VARCHAR(20) constraint poz_chk 
    CHECK (pozycja in('bramkarz', 'obronca', 'napastnik', 'pomocnik')),
    klub VARCHAR(50) DEFAULT 'wolny zawodnik',
    liczba_minut NUMBER(4) default 0,
    placa NUMBER(10,2) constraint placa_chk CHECK(NVL(placa, 0)>=0)
);


INSERT INTO Zawodnicy VALUES(1001, 'Nowak', 'Piotr',
TO_DATE('10.01.1990', 'DD.MM.YYYY'), 192, 81.5, 'bramkarz', 
'Warta Czestochowa', 360, 4000);

INSERT INTO Zawodnicy VALUES(1007, 'Oleksy', 'Robert',
TO_DATE('12.08.1996', 'DD.MM.YYYY'), 185, 85, 'obronca', 
NULL , NULL, NULL);

INSERT INTO Zawodnicy (nazwisko, imie, id_zawodnika, data_ur,
wzrost, waga, pozycja) VALUES('Kowalski', 'Jan', 999,
TO_DATE('12.08.1998', 'DD.MM.YYYY'), 187, 100, 'obronca');




INSERT INTO Zawodnicy VALUES (1002, 'Kowalski', 'Adam', To_date('15-04-1992', 'DD-MM-YYYY'), 194, 83, 'bramkarz', 'Odra Wroclaw', 270, 3500);
INSERT INTO Zawodnicy VALUES (1003, 'Polak', 'Dariusz', To_date('11-06-1998', 'DD-MM-YYYY'), 189, 79.5, 'bramkarz', 'Wisla Warszawa', 450, 5000);

INSERT INTO Zawodnicy VALUES (1004, 'Malinowski', 'Adrian', To_date('21-11-1987', 'DD-MM-YYYY'), 190, 85, 'obronca', 'Warta Czestochowa', 300, 3000);
INSERT INTO Zawodnicy VALUES (1005, 'Czech', 'Piotr', To_date('04-12-1989', 'DD-MM-YYYY'), 187, 83, 'obronca', 'Odra Wroclaw', 200, 2600);
INSERT INTO Zawodnicy VALUES (1006, 'Podolski', 'Krystian', To_date('26-02-1997', 'DD-MM-YYYY'), 186, 89, 'obronca', 'Wisla Warszawa', 350, 3500);

INSERT INTO Zawodnicy VALUES (1008, 'Grzyb', 'Krzysztof', To_date('17-09-1995', 'DD-MM-YYYY'), 173, 75, 'pomocnik', 'Warta Czestochowa', 400, 3200);
INSERT INTO Zawodnicy VALUES (1009, 'Kwasek', 'Artur', To_date('30-10-1991', 'DD-MM-YYYY'), 180, 75, 'pomocnik', 'Odra Wroclaw', 370, 3300);
INSERT INTO Zawodnicy VALUES (1010, 'Kukla', 'Kamil', To_date('01-02-1993', 'DD-MM-YYYY'), 179, 75, 'pomocnik', 'Wisla Warszawa', 250, 3000);
INSERT INTO Zawodnicy (id_zawodnika, nazwisko, imie, data_ur, wzrost, waga, pozycja) VALUES
(1011, 'Drozd', 'Adam', To_date('19-03-1995', 'DD-MM-YYYY'), 182, 77, 'pomocnik');

INSERT INTO Zawodnicy VALUES (1012, 'Jankowski', 'Marek', To_date('23-09-1999', 'DD-MM-YYYY'), 185, 80, 'napastnik', 'Warta Czestochowa', 60, 2000);
INSERT INTO Zawodnicy VALUES (1013, 'Knysak', 'Fabian', To_date('10-10-1994', 'DD-MM-YYYY'), 175, 73, 'napastnik', 'Odra Wroclaw', 250, 4000);
INSERT INTO Zawodnicy VALUES (1014, 'Tyrek', 'Tomasz', To_date('31-01-1998', 'DD-MM-YYYY'), 179, 74, 'napastnik', 'Wisla Warszawa', 200, 6000);
INSERT INTO Zawodnicy VALUES (1015, 'Zachara', 'Mateusz', To_date('09-09-2000', 'DD-MM-YYYY'), 181, 73, 'napastnik', NULL, NULL, NULL);

INSERT INTO Zawodnicy VALUES (1016, 'Jaskola', 'Milosz', To_date('13-09-1997', 'DD-MM-YYYY'), 187, 81, 'napastnik', 'Warta Czestochowa', 160, 2300);
INSERT INTO Zawodnicy VALUES (1017, 'Knus', 'Franciszek', To_date('10-03-1984', 'DD-MM-YYYY'), 177, 71, 'napastnik', 'Odra Wroclaw', NULL, 3700);
INSERT INTO Zawodnicy VALUES (1018, 'Toborek', 'Tomasz', To_date('31-03-1997', 'DD-MM-YYYY'), 183, 72, 'napastnik', 'Wisla Warszawa', 230, 6200);
INSERT INTO Zawodnicy VALUES (1019, 'Zasepa', 'Michal', To_date('19-09-2001', 'DD-MM-YYYY'), 180, 76, 'napastnik', NULL, NULL, NULL);

INSERT INTO Zawodnicy VALUES (1020, 'Borel', 'Jan', To_date('11-02-2002', 'DD-MM-YYYY'), 179, 75, 'pomocnik', 'Warta Czestochowa', NULL, NULL);
INSERT INTO Zawodnicy VALUES (1021, 'Czok', 'Damian', To_date('28-08-1995', 'DD-MM-YYYY'), 190, 82, 'obronca', 'Odra Wroclaw', NULL, NULL);


SELECT * FROM Zawodnicy;

commit;

---zad 2
delete from zawodnicy where data_ur>sysdate - interval '21' year;
--b
delete from zawodnicy;
--c
select * from zawodnicy;
--d
ROLLBACK;
--e
select * from zawodnicy;
--f
drop table zawodnicy CASCADE CONSTRAINTS;
--g
rollback;
--h
select * from zawodnicy;
--i
--- realizacja zad 1

-- zad 3
select * from zawodnicy;

update zawodnicy set klub = 'wolny zawodnik', liczba_minut = 0,
placa =0 where klub is null;

--zad 4
update zawodnicy set liczba_minut = nvl(liczba_minut,0) + 
case when liczba_minut>100 then 90
when liczba_minut between 1 and 100 then 45
else 15 end where klub in ('Warta Czestochowa','Odra Wroclaw');

commit;

--- 9
UPDATE zawodnicy z
SET z.klub = 'wolny zawodnik', z.placa = 0
WHERE klub IS NOT NULL
AND klub != 'wolny zawodnik'
AND z.data_ur = 
(
SELECT MAX(data_ur)
FROM zawodnicy
WHERE klub IS NOT NULL
AND klub != 'wolny zawodnik'
--WHERE klub = z.klub
)
AND z.liczba_minut <
(
SELECT MAX(liczba_minut)
FROM zawodnicy
WHERE klub = z.klub
);

--zad 7
update zawodnicy set klub='Warta Czestochowa',placa=NVL(placa,0)+2500 
where id_zawodnika=
(select id_zawodnika from zawodnicy where klub like 'Odra Wroclaw' AND data_ur=
(select max(data_ur) from zawodnicy where klub like 'Odra Wroclaw') and ROWNUM=1);

select * from zawodnicy;

-- zad 5
update zawodnicy z set placa=placa*case when liczba_minut =
(select max(liczba_minut) from zawodnicy where klub = z.klub) then 1.25
when liczba_minut =
(select min(liczba_minut) from zawodnicy where klub = z.klub) then 0.9
else 1 end where klub is not null and klub not like 'wolny zawodnik';


select * from zawodnicy where ROWNUM=1;