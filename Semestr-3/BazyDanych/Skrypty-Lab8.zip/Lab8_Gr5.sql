--zad 1
CREATE TABLE Zawodnicy
(
id_zawodnika NUMBER(4) constraint Zawodnicy_id_pk PRIMARY KEY,
nazwisko VARCHAR2(30) constraint Zawodnicy_nazwisko_NN NOT NULL,
imie VARCHAR(30) constraint Zawodnicy_imie_NN NOT NULL,
data_ur DATE constraint Zawodnicy_data_ck CHECK (extract(YEAR FROM data_ur)>1950),
wzrost NUMBER(3) constraint Zawodnicy_wzrost_ck CHECK (wzrost between 0 and 220),
waga NUMBER(5,2) constraint Zawodnicy_waga_ck CHECK (waga between 0 and 120.00),
pozycja VARCHAR2(30) constraint Zawodnicy_pozycja_ck 
    CHECK (pozycja in ('bramkarz', 'obronca', 'pomocnik', 'napastnik')),
klub VARCHAR2(50) DEFAULT 'wolny zawodnik',
liczba_minut NUMBER(4) DEFAULT 0,
placa NUMBER(4)
);

--drop table zawodnicy CASCADE CONSTRAINTS;


--zad 2

/*
insert into Zawodnicy(id_zawodnika, nazwisko, imie, data_ur, waga, wzrost, pozycja) 
values(1007, 'Oleksy', 'Robert', to_date('12.08.1996', 'dd.mm.yyyy'), 
85, 185, 'obronca');
*/

insert into Zawodnicy values(1001, 'Nowak', 'Piotr', 
to_date('10.01.1990', 'dd.mm.yyyy'), 192, 81.5, 'bramkarz', 'Warta Czestochowa',
360, 4000);

insert into Zawodnicy(id_zawodnika, nazwisko, imie, data_ur, waga, wzrost, pozycja,
klub, liczba_minut, placa) 
values(1007, 'Oleksy', 'Robert', to_date('12.08.1996', 'dd.mm.yyyy'), 
85, 185, 'obronca', null, null, null);


INSERT INTO Zawodnicy VALUES (1002, 'Kowalski', 'Adam', To_date('15-04-1992', 'DD-MM-YYYY'), 194, 83, 'bramkarz', 'Odra Wroclaw', 270, 3500);
INSERT INTO Zawodnicy VALUES (1003, 'Polak', 'Dariusz', To_date('11-06-1998', 'DD-MM-YYYY'), 189, 79.5, 'bramkarz', 'Wisla Warszawa', 450, 5000);

INSERT INTO Zawodnicy VALUES (1004, 'Malinowski', 'Adrian', To_date('21-11-1987', 'DD-MM-YYYY'), 190, 85, 'obronca', 'Warta Czestochowa', 300, 3000);
INSERT INTO Zawodnicy VALUES (1005, 'Czech', 'Piotr', To_date('04-12-1989', 'DD-MM-YYYY'), 187, 83, 'obronca', 'Odra Wroclaw', 200, 2600);
INSERT INTO Zawodnicy VALUES (1006, 'Podolski', 'Krystian', To_date('26-02-1997', 'DD-MM-YYYY'), 186, 89, 'obronca', 'Wisla Warszawa', 350, 3500);

INSERT INTO Zawodnicy VALUES (1008, 'Grzyb', 'Krzysztof', To_date('17-09-1995', 'DD-MM-YYYY'), 173, 75, 'pomocnik', 'Warta Czestochowa', 400, 3200);
INSERT INTO Zawodnicy VALUES (1009, 'Kwasek', 'Artur', To_date('30-10-1991', 'DD-MM-YYYY'), 180, 75, 'pomocnik', 'Odra Wroclaw', 370, 3300);
INSERT INTO Zawodnicy VALUES (1010, 'Kukla', 'Kamil', To_date('01-02-1993', 'DD-MM-YYYY'), 179, 75, 'pomocnik', 'Wisla Warszawa', 250, 3000);
INSERT INTO Zawodnicy (id_zawodnika, nazwisko, imie, data_ur, wzrost, waga, pozycja) VALUES
(1011, 'Drozd', 'Adam', To_date('19-03-1995', 'DD-MM-YYYY'), 182, 77, 'pomocnik');

INSERT INTO Zawodnicy VALUES (1012, 'Jankowski', 'Marek', To_date('23-09-1999', 'DD-MM-YYYY'), 185, 80, 'napastnik', 'Warta Czestochowa', 60, 2000);
INSERT INTO Zawodnicy VALUES (1013, 'Knysak', 'Fabian', To_date('10-10-1994', 'DD-MM-YYYY'), 175, 73, 'napastnik', 'Odra Wroclaw', 250, 4000);
INSERT INTO Zawodnicy VALUES (1014, 'Tyrek', 'Tomasz', To_date('31-01-1998', 'DD-MM-YYYY'), 179, 74, 'napastnik', 'Wisla Warszawa', 200, 6000);
INSERT INTO Zawodnicy VALUES (1015, 'Zachara', 'Mateusz', To_date('09-09-2000', 'DD-MM-YYYY'), 181, 73, 'napastnik', NULL, NULL, NULL);

INSERT INTO Zawodnicy VALUES (1016, 'Jaskola', 'Milosz', To_date('13-09-1997', 'DD-MM-YYYY'), 187, 81, 'napastnik', 'Warta Czestochowa', 160, 2300);
INSERT INTO Zawodnicy VALUES (1017, 'Knus', 'Franciszek', To_date('10-03-1984', 'DD-MM-YYYY'), 177, 71, 'napastnik', 'Odra Wroclaw', NULL, 3700);
INSERT INTO Zawodnicy VALUES (1018, 'Toborek', 'Tomasz', To_date('31-03-1997', 'DD-MM-YYYY'), 183, 72, 'napastnik', 'Wisla Warszawa', 230, 6200);
INSERT INTO Zawodnicy VALUES (1019, 'Zasepa', 'Michal', To_date('19-09-2001', 'DD-MM-YYYY'), 180, 76, 'napastnik', NULL, NULL, NULL);

INSERT INTO Zawodnicy VALUES (1020, 'Borel', 'Jan', To_date('11-02-2002', 'DD-MM-YYYY'), 179, 75, 'pomocnik', 'Warta Czestochowa', NULL, NULL);
INSERT INTO Zawodnicy VALUES (1021, 'Czok', 'Damian', To_date('28-08-1995', 'DD-MM-YYYY'), 190, 82, 'obronca', 'Odra Wroclaw', NULL, NULL);

commit;
select * from zawodnicy;

--rollback;

--zad 2
delete from zawodnicy where data_ur> sysdate- Interval '21' Year;
delete from zawodnicy;
select * from zawodnicy;
rollback;
select * from zawodnicy;
drop table zawodnicy cascade constraints;
-- zrob zad 1 z danymi
select * from zawodnicy;
commit;

--zad 3
select * from zawodnicy;
update zawodnicy set klub = 'wolny zawodnik', liczba_minut = 0, placa= 0
where klub is null;
commit;

--zad 5
select * from zawodnicy;
update zawodnicy z1 set placa = placa * 1.25 where liczba_minut = (
select max(liczba_minut) from zawodnicy where klub = z1.klub) and klub not like
'wolny zawodnik';

update zawodnicy z1 set placa = placa * 0.9 where nvl(liczba_minut, 0) = (
select min(nvl(liczba_minut, 0)) from zawodnicy where klub = z1.klub) and klub not like
'wolny zawodnik';

rollback;

-- zad 6
update zawodnicy set klub =
(select * from(
select klub from Zawodnicy where   klub !='wolny zawodnik'group by klub having count(*)=
(select min(count(*))from Zawodnicy where  klub !='wolny zawodnik'group by klub ))
where ROWNUM =1)
where klub ='wolny zawodnik'  ;

select min(count(*))from Zawodnicy where  klub !='wolny zawodnik'group by klub ;
select * from zawodnicy where ROWNUM =1;

