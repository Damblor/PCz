

--zad 1
create table produkty
(
id_produktu number(4) CONSTRAINT pr_id_produktu_un UNIQUE,
nazwa VARCHAR(40)CONSTRAINT pr_nazwa_nn not null,
stan number(6,2) default 0,
cena number(6,2) default 1.23,
wartosc as (cena*stan)
);

create table kasjerzy
(
id_kasjera number(5)CONSTRAINT ka_id_kasjera_pk PRIMARY key,
nazwisko VARCHAR(20),
data_zatrudnienia date CONSTRAINT ka_data_zat_nn not null,
placa number(7,2) 
);

-- zad 3
create table transakcje
(
id_transakcji number(8) constraint tr_id_transakcji_pr primary key,
id_produktu number(4) constraint tr_id_produktu_nn not null,
id_sprzedawcy number(5) constraint tr_id_sprzedawcy_nn not null,
miara number(6,2) default 1,
czas_transakcji timestamp,
constraint tr_id_produktu_fk foreign key (id_produktu) references 
produkty (id_produktu),
constraint tr_id_sprzedawcy_fk foreign key (id_sprzedawcy) references
kasjerzy (id_kasjera)
);

--zad 4
--a
ALTER TABLE kasjerzy modify(placa default 3200);
--b
ALTER TABLE transakcje modify(czas_transakcji default systimestamp);
--c
ALTER TABLE kasjerzy add CONSTRAINT ka_id_kasjera_ch check (id_kasjera>=100);
--d
ALTER TABLE transakcje drop constraint tr_id_produktu_fk;
ALTER TABLE produkty drop constraint pr_id_produktu_un;
ALTER TABLE produkty add constraint pr_id_produktu_pk primary key(id_produktu);
ALTER TABLE transakcje add constraint tr_id_produktu_fk foreign key (id_produktu) references 
produkty (id_produktu) ON DELETE CASCADE;
--e
ALTER TABLE transakcje drop constraint tr_id_sprzedawcy_nn;
ALTER TABLE transakcje drop constraint tr_id_sprzedawcy_fk;
ALTER TABLE transakcje add constraint tr_id_sprzedawcy_fk 
foreign key (id_sprzedawcy) references kasjerzy (id_kasjera)
ON DELETE SET NULL;
--f
alter table kasjerzy rename column placa to pensja;
--g
alter table kasjerzy add (data_urodzenia date constraint ka_data_ur_ch 
check(data_urodzenia>=to_date('01.01.1960', 'DD.MM.YYYY' )),
data_zwolnienia date default null);
--h
alter table kasjerzy add constraint ka_data_zwol_ch 
check (NVL(data_zwolnienia,data_urodzenia+1)>data_urodzenia 
and NVL(data_zwolnienia,data_zatrudnienia+1)>data_zatrudnienia);
--i
alter table produkty modify(wartosc number(5,2));


-- Po zadaniu 4
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(1, 'cukier', 100, 2.95);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(2, 'chleb', 50, 3.7);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(3, 'jogurt', 20, 1.15);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(4, 'schab', 6.5, 15.2);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(5, 'piwo', 200, 3.1);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(6, 'cukierki', 10, 23);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(7, 'kurczak', 10, 12.35);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(8, 'banan', 6.5, 5.20);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(9, 'mydlo', 40, 2.5);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(10, 'pomidory', 8.5, 8.5);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(11, 'olej', 20, 6.95);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(12, 'kisiel', 150, 1.15);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(13, 'ciastka', 25, 4.80);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(14, 'plyn do naczyn', 15, 8.20);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(15, 'pieprz', 30, 3.15);


INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia) VALUES
(100, 'Kowalski', To_date('01-01-2010', 'DD-MM-YYYY'), To_date('11-03-1990', 'DD-MM-YYYY'));
INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia) VALUES
(101, 'Nowak', To_date('01-03-2012', 'DD-MM-YYYY'), To_date('21-10-1992', 'DD-MM-YYYY'));
INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia) VALUES
(102, 'Polak', To_date('01-10-2013', 'DD-MM-YYYY'), To_date('18-09-1983', 'DD-MM-YYYY'));
INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia) VALUES
(103, 'Zalas', To_date('01-01-2019', 'DD-MM-YYYY'), To_date('14-12-1985', 'DD-MM-YYYY'));
INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia) VALUES
(104, 'Pogonowska', To_date('01-11-2018', 'DD-MM-YYYY'), To_date('28-03-1993', 'DD-MM-YYYY'));

INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (1, 1, 100, 2);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (2, 1, 101, 1);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (3, 2, 100, 1);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (4, 3, 102, 5);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (5, 4, 100, 1.35);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (6, 5, 101, 4);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (7, 6, 100, 0.45);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (8, 7, 102, 1.84);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (9, 4, 101, 1.05);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (10, 6, 102, 1.55);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (11, 6, 102, 0.8);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (12, 7, 102, 2.5);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (13, 7, 103, 1.95);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (14, 11, 100, 2);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (15, 11, 104, 1);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (16, 12, 102, 8);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (17, 12, 103, 4);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (18, 12, 104, 5);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (19, 12, 103, 11);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (20, 13, 104, 2);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (21, 14, 102, 1);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (22, 14, 101, 2);

---INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (22, 55, 101, 2);

commit;

--zad 5
select * from produkty;
select * from transakcje;

alter table transakcje add rachunek number(8,2);
update produkty pr set stan = stan - (select sum(miara) from transakcje
where id_produktu = pr.id_produktu and rachunek is null) where
exists(select * from transakcje
where id_produktu = pr.id_produktu and rachunek is null);

update transakcje tr set rachunek = miara*(select cena from produkty 
where id_produktu = tr.id_produktu) where rachunek is null;  
commit;

-- do zadania 6
INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia)
VALUES (10, 'Malinowska', sysdate, To_date('13-05-1958', 'DD-MM-YYYY'));
alter table kasjerzy DISABLE CONSTRAINT ka_id_kasjera_ch;
alter table kasjerzy DISABLE CONSTRAINT ka_data_ur_ch;
INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia)
VALUES (10, 'Malinowska', sysdate, To_date('13-05-1958', 'DD-MM-YYYY'));
alter table kasjerzy ENABLE CONSTRAINT ka_id_kasjera_ch;
alter table kasjerzy ENABLE CONSTRAINT ka_data_ur_ch;
update kasjerzy set id_kasjera=decode((select max(id_kasjera)+1 from kasjerzy),
11,100,null,100,(select max(id_kasjera)+1 from kasjerzy))
where id_kasjera=10;
alter table kasjerzy ENABLE CONSTRAINT ka_id_kasjera_ch;
alter table kasjerzy ENABLE NOVALIDATE CONSTRAINT ka_data_ur_ch;

--zad 7
create table raport as(
select nazwa produkt, pr.id_produktu, nazwisko kasjer,id_kasjera,
count(id_transakcji) liczba_transakcji, sum(nvl(miara,0)) lacznie_kg_szt,
sum(nvl(rachunek,0)) rachunek from transakcje tr 
right join produkty pr on (pr.id_produktu = tr.id_produktu)
full join kasjerzy ka on (tr.id_sprzedawcy=ka.id_kasjera)
group by nazwa, pr.id_produktu, nazwisko, id_kasjera);
select * from raport;


drop table Transakcje cascade constraints;
drop table Produkty cascade constraints;
drop table Kasjerzy cascade constraints;
-- do zadania 8
-- przy zalo?eniu, ?e id_kasjera nowej kasjerski Malinowskiej to 105
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (23, 14, 105, 1);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (24, 15, 105, 2);







