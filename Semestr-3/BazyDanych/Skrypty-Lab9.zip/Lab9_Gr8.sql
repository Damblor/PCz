--zad 1
drop table Transakcji cascade constraints;
drop table Kasjerzy cascade constraints;
drop table Produkty cascade constraints;


create table Produkty(
id_produktu number (4) constraint id_produktu_un unique,
nazwa varchar (40) constraint nazwa_nn not null,
stan number(6,2) default 0,
cena number (6,2) default 1.23,
wartosc as (stan*cena)
);

--zad 2
create table Kasjerzy(
id_kasjera number (5) constraint kasjerzy_pk primary key,
nazwisko varchar(20) ,
data_zatrudnienia date constraint data_zatr_nn not null,
placa number(7,2) 
);

-- zad 3
create table Transakcje(
id_transakcji number (8) constraint transakcje_pk primary key,
id_produktu number(4) constraint id_prod_nn not null,
id_sprzedawcy number(5) constraint id_sprzed_nn not null,
miara number(6,2) default 1,
czas_transakcji timestamp,
constraint id_produktu_fk FOREIGN key (id_produktu) REFERENCES produkty (id_produktu),
constraint id_sprzedawcy_fk FOREIGN key (id_sprzedawcy) REFERENCES kasjerzy (id_kasjera)
);

-- zad 4 
alter table Kasjerzy modify (placa default 3200);

--b
alter table Transakcje modify (czas_transakcji default systimestamp);

--c
alter table Kasjerzy add constraint id_kasjera_ch check (id_kasjera>=100);

--d
alter table Transakcje drop constraint id_produktu_fk;
alter table Produkty drop constraint id_produktu_un;
alter table Produkty add constraint produkty_pk primary key (id_produktu);
alter table Transakcje add constraint id_produktu_fk FOREIGN key (id_produktu) 
REFERENCES produkty (id_produktu) on delete cascade;
--e
alter table Transakcje drop constraint id_sprzed_nn;
alter table Transakcje drop constraint id_sprzedawcy_fk;
alter table Transakcje add constraint id_sprzedawcy_fk FOREIGN key (id_sprzedawcy)
REFERENCES kasjerzy (id_kasjera) on delete SET null;
--f 
alter table Kasjerzy rename column placa to pensja;
--g
alter table Kasjerzy add(data_urodzenia date constraint data_urodzenia_ch 
check ( data_urodzenia >= to_date('01-01-1960','dd-mm-yyyy') ),
data_zwolnienia date default null);
--h
alter table Kasjerzy add constraint data_zwol_ch 
check (nvl(data_zwolnienia,data_urodzenia) >= data_urodzenia and
nvl(data_zwolnienia,data_zatrudnienia) >= data_zatrudnienia) ;
--i
alter table Produkty modify (wartosc number(9,2));

-- Po zadaniu 4
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(1, 'cukier', 100, 2.95);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(2, 'chleb', 50, 3.7);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(3, 'jogurt', 20, 1.15);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(4, 'schab', 6.5, 15.2);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(5, 'piwo', 200, 3.1);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(6, 'cukierki', 10, 23);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(7, 'kurczak', 10, 12.35);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(8, 'banan', 6.5, 5.20);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(9, 'mydlo', 40, 2.5);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(10, 'pomidory', 8.5, 8.5);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(11, 'olej', 20, 6.95);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(12, 'kisiel', 150, 1.15);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(13, 'ciastka', 25, 4.80);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(14, 'plyn do naczyn', 15, 8.20);
INSERT INTO Produkty (id_produktu, nazwa, stan, cena) VALUES(15, 'pieprz', 30, 3.15);


INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia) VALUES
(100, 'Kowalski', To_date('01-01-2010', 'DD-MM-YYYY'), To_date('11-03-1990', 'DD-MM-YYYY'));
INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia) VALUES
(101, 'Nowak', To_date('01-03-2012', 'DD-MM-YYYY'), To_date('21-10-1992', 'DD-MM-YYYY'));
INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia) VALUES
(102, 'Polak', To_date('01-10-2013', 'DD-MM-YYYY'), To_date('18-09-1983', 'DD-MM-YYYY'));
INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia) VALUES
(103, 'Zalas', To_date('01-01-2019', 'DD-MM-YYYY'), To_date('14-12-1985', 'DD-MM-YYYY'));
INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia) VALUES
(104, 'Pogonowska', To_date('01-11-2018', 'DD-MM-YYYY'), To_date('28-03-1993', 'DD-MM-YYYY'));

INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (1, 1, 100, 2);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (2, 1, 101, 1);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (3, 2, 100, 1);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (4, 3, 102, 5);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (5, 4, 100, 1.35);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (6, 5, 101, 4);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (7, 6, 100, 0.45);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (8, 7, 102, 1.84);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (9, 4, 101, 1.05);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (10, 6, 102, 1.55);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (11, 6, 102, 0.8);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (12, 7, 102, 2.5);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (13, 7, 103, 1.95);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (14, 11, 100, 2);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (15, 11, 104, 1);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (16, 12, 102, 8);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (17, 12, 103, 4);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (18, 12, 104, 5);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (19, 12, 103, 11);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (20, 13, 104, 2);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (21, 14, 102, 1);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (22, 14, 101, 2);

commit;
--zad 
select * from kasjerzy;
select * from transakcje;
SELECt  * FROM produkty;


alter table Transakcje add rachunek number (8,2);
update produkty p1 set stan=stan-(
select sum(miara) from transakcje where id_produktu=p1.id_produktu and rachunek is null
)where exists(select * from transakcje where id_produktu=p1.id_produktu and rachunek is null);

update transakcje t1 set rachunek=miara*(select cena from produkty where id_produktu=t1.id_produktu)
where rachunek is null;

rollback;

-- do zadania 6
INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia) 
VALUES (10, 'Malinowska', sysdate, To_date('13-05-1958', 'DD-MM-YYYY'));

alter table kasjerzy disable constraint data_urodzenia_ch;
alter table kasjerzy disable constraint id_kasjera_ch;

INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia) 
VALUES (10, 'Malinowska', sysdate, To_date('13-05-1958', 'DD-MM-YYYY'));

alter table kasjerzy enable constraint data_urodzenia_ch;
alter table kasjerzy enable constraint id_kasjera_ch;
update kasjerzy set id_kasjera = case when (select max(id_kasjera)+1 from kasjerzy)<100 
then 100 else (select max(id_kasjera)+1 from kasjerzy) end where id_kasjera =10;

alter table kasjerzy enable novalidate constraint data_urodzenia_ch;
alter table kasjerzy enable constraint id_kasjera_ch;

INSERT INTO Kasjerzy (id_kasjera, nazwisko, data_zatrudnienia, data_urodzenia) 
VALUES (230, 'Malinowska', sysdate, To_date('13-05-1963', 'DD-MM-YYYY'));
/*
-- do zadania 8
-- przy zalo?eniu, ?e id_kasjera nowej kasjerski Malinowskiej to 105
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (23, 14, 105, 1);
INSERT INTO Transakcje (id_transakcji, id_produktu, id_sprzedawcy, miara) VALUES (24, 15, 105, 2);
*/




