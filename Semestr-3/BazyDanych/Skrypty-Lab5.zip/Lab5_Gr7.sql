--zad 2
select extract(year from czas) as rok, gatunki.nazwa, dlugosc, trunc(czas), 
nazwisko,lowiska.nazwa
from rejestry join gatunki using(id_gatunku) join wedkarze
using(id_wedkarza)join lowiska using (id_lowiska)
where (extract(year from czas),id_gatunku,dlugosc)in (
select extract(year from czas) rok,id_gatunku,max(dlugosc)
from rejestry group by extract(year from czas), id_gatunku) order by 1,2;
--zad 3
select waga, gatunki.nazwa, lowiska.nazwa, nazwisko, imiona, trunc(czas)
from rejestry join gatunki using(id_gatunku) join wedkarze
using(id_wedkarza)join lowiska using (id_lowiska)
where trim (to_char(czas,'month')) like 'maj' 
and trim (to_char(czas,'day')) in('sobota','niedziela') and waga = 
(select max(waga) from rejestry 
where trim (to_char(czas,'month')) like 'maj' 
and trim (to_char(czas,'day')) in('sobota','niedziela'));

select id_wedkarza, nazwisko, 
(select count(*) from rejestry where id_gatunku=1 and id_wedkarza=we.id_wedkarza) Karp,
(select count(*) from rejestry where id_gatunku=2 and id_wedkarza=we.id_wedkarza) Lin
from wedkarze we;

--zad 6
select max(liczba) from (
select id_wlasciciela,count(VIN)liczba from pojazdy 
where typ in('SAM_OSOBOWY','MOTOCYKL')
group by id_wlasciciela);

select max(count(VIN))liczba from pojazdy 
where typ in('SAM_OSOBOWY','MOTOCYKL')
group by id_wlasciciela;

select id_wlasciciela, wlasciciel, adres, count(VIN)liczb 
from wlasciciele join pojazdy using (id_wlasciciela)
where typ in('SAM_OSOBOWY','MOTOCYKL')
group by wlasciciel, id_wlasciciela, adres having count(VIN)=
(select max(count(VIN))liczba from pojazdy 
where typ in('SAM_OSOBOWY','MOTOCYKL')
group by id_wlasciciela);

select * from 
(select id_wlasciciela, wlasciciel, adres, count(VIN)liczb 
from wlasciciele join pojazdy using (id_wlasciciela)
where typ in('SAM_OSOBOWY','MOTOCYKL')
group by wlasciciel, id_wlasciciela, adres)t1 
join 
(select max(count(VIN))liczba from pojazdy 
where typ in('SAM_OSOBOWY','MOTOCYKL')
group by id_wlasciciela)t2 on (t1.liczb >= t2.liczba*0.5);
--zad 16
select id_okregu ,max(laczna_waga)max_waga from 
(select ID_okregu,id_lowiska,sum(waga)laczna_waga
from rejestry join   lowiska using(id_lowiska) 
where id_okregu like 'PZW%' group by ID_okregu,id_lowiska)
group by id_okregu ;

 select id_okregu,id_lowiska,nazwa,sum(waga),count (*),count(id_gatunku)
 from rejestry join lowiska using (id_lowiska)
 where id_okregu like 'PZW%'group by id_okregu,id_lowiska,nazwa;

 select * from 
 (select id_okregu ,max(laczna_waga)max_waga from 
(select ID_okregu,id_lowiska,sum(waga)laczna_waga
from rejestry join   lowiska using(id_lowiska) 
where id_okregu like 'PZW%' group by ID_okregu,id_lowiska)
group by id_okregu)t1 join 
(select id_okregu,id_lowiska,nazwa,sum(waga)laczna_waga,count (*),count(id_gatunku)
 from rejestry join lowiska using (id_lowiska)
 where id_okregu like 'PZW%'group by id_okregu,id_lowiska,nazwa)t2
 on (t1.id_okregu=t2.id_okregu and max_waga= laczna_waga)order by 6 desc;
 --zad 19
 select decode(grouping(wlasciciel),1,'razem',wlasciciel) wlasciciel,
 id_wlasciciela,typ,marka,count(VIN),
 GROUPING_ID(wlasciciel,id_wlasciciela,typ,marka)
 from wlasciciele join pojazdy using(id_wlasciciela)
 group by grouping sets((wlasciciel,id_wlasciciela,typ,marka),
 (wlasciciel,id_wlasciciela,typ),(wlasciciel,id_wlasciciela,marka),())
;  