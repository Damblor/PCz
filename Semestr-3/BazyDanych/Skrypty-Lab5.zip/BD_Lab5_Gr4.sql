--zad X
/*
 Najstarszy pojazd nale�acy do osoby fizycznej wyprodukowany w 21 wieku
*/
SELECT * FROM pojazdy
JOIN wlasciciele USING(id_wlasciciela)
WHERE status_wlasciciela LIKE 'osoba_fizyczna'
AND data_produkcji =
(
SELECT MIN(data_produkcji) FROM pojazdy
JOIN wlasciciele USING(id_wlasciciela)
WHERE status_wlasciciela LIKE 'osoba_fizyczna'
AND TO_NUMBER(TO_CHAR(data_produkcji, 'CC')) = 21
);

SELECT MIN(data_produkcji) FROM pojazdy
JOIN wlasciciele USING(id_wlasciciela)
WHERE status_wlasciciela LIKE 'osoba_fizyczna'
AND TO_NUMBER(TO_CHAR(data_produkcji, 'CC')) = 21;

SELECT * FROM wlasciciele;

--inaczej

select * from 
(SELECT * FROM pojazdy JOIN wlasciciele USING(id_wlasciciela)
WHERE status_wlasciciela LIKE 'osoba_fizyczna') T1 JOIN
(SELECT MIN(data_produkcji) najstarszy FROM pojazdy
JOIN wlasciciele USING(id_wlasciciela)
WHERE status_wlasciciela LIKE 'osoba_fizyczna'
AND TO_NUMBER(TO_CHAR(data_produkcji, 'CC')) = 21) T2 
on(t1.data_produkcji=t2.najstarszy);

-- zad 6
SELECT Max(liczba) from 
(Select id_wlasciciela, count(*) liczba from pojazdy where typ in ('SAM_OSOBOWY','MOTOCYKL')
group by id_wlasciciela);

Select max(count(*)) maxliczba from pojazdy where typ in ('SAM_OSOBOWY','MOTOCYKL')
group by id_wlasciciela;

SELECT id_wlasciciela, wlasciciel, adres, count(*) liczba 
FROM pojazdy JOIN wlasciciele USING(id_wlasciciela) 
where typ in ('SAM_OSOBOWY','MOTOCYKL') group by id_wlasciciela, wlasciciel, adres;


SELECT id_wlasciciela, wlasciciel, adres, count(*) liczba 
FROM pojazdy JOIN wlasciciele USING(id_wlasciciela) 
where typ in ('SAM_OSOBOWY','MOTOCYKL') group by id_wlasciciela, wlasciciel, adres
having count(*)>=(Select max(count(*)) maxliczba from pojazdy
where typ in ('SAM_OSOBOWY','MOTOCYKL')
group by id_wlasciciela)*0.5;


SELECT wl.id_wlasciciela, wlasciciel, status_wlasciciela,  adres, count(*) liczba 
FROM pojazdy po JOIN wlasciciele wl on(po.id_wlasciciela=wl.id_wlasciciela) 
where typ in ('SAM_OSOBOWY','MOTOCYKL') 
group by wl.id_wlasciciela, wlasciciel, adres, status_wlasciciela
having count(*)=
(Select max(count(*)) maxliczba 
from pojazdy poj JOIN wlasciciele wla on(poj.id_wlasciciela=wla.id_wlasciciela)
where typ in ('SAM_OSOBOWY','MOTOCYKL') and 
wla.status_wlasciciela=wl.status_wlasciciela
group by wla.id_wlasciciela);

--zad 7

SELECT wl.id_wlasciciela, wlasciciel, adres, count(*) liczba,
(select count(*) from pojazdy where typ like 'SAM_OSOBOWY' 
and id_wlasciciela=wl.id_wlasciciela) Liczba_Sam,
(select count(*) from pojazdy where typ like 'MOTOCYKL' 
and id_wlasciciela=wl.id_wlasciciela) Liczba_Mot
FROM pojazdy po JOIN wlasciciele wl on(po.id_wlasciciela=wl.id_wlasciciela) 
where typ in ('SAM_OSOBOWY','MOTOCYKL') group by wl.id_wlasciciela, wlasciciel, adres
having count(*)=(Select max(count(*)) maxliczba from pojazdy
where typ in ('SAM_OSOBOWY','MOTOCYKL')
group by id_wlasciciela);

--
/*wyswietl informacje ile pojazdow z danym rodzajem napedu posiada danych 
wlasciel - uwzglednij wszystkich wlascicieli i  wszystkie notowane rodzeje napedu
*/
SELECT rodzaj_paliwa, id_wlasciciela, wlasciciel, 
(SELECT COUNT(VIN) FROM pojazdy WHERE rodzaj_paliwa= T1.rodzaj_paliwa AND
id_wlasciciela=T2.id_wlasciciela) liczba
FROM
(select DISTINCT rodzaj_paliwa from pojazdy) T1 CROSS JOIN wlasciciele T2 ORDER BY 2;

SELECT T1.rodzaj_paliwa, T2.id_wlasciciela, T2.wlasciciel, COUNT(VIN)
FROM
(select DISTINCT rodzaj_paliwa from pojazdy) T1 CROSS JOIN wlasciciele T2 
LEFT JOIN pojazdy T3 ON (T3.rodzaj_paliwa=T1.rodzaj_paliwa 
AND T3.id_wlasciciela=T2.ID_WLASCICIELA) 
GROUP BY T1.rodzaj_paliwa, T2.id_wlasciciela, T2.wlasciciel ORDER BY 2;

--zad 17
select decode(grouping(tryb), 1, 'podsumowanie', tryb) tryb, 
stopien, kierunek, rok, count(*), 
grouping_id(tryb, stopien, kierunek, rok) liczba
from studenci 
group by rollup (tryb, stopien, kierunek, rok);

select decode(grouping(tryb), 1, 'podsumowanie', tryb) tryb, 
stopien, kierunek, rok, count(*), 
grouping_id(tryb, stopien, kierunek, rok) liczba
from studenci 
group by cube(tryb, stopien, kierunek, rok);

select decode(grouping(tryb), 1, 'podsumowanie', tryb) tryb, 
stopien, kierunek, rok, count(*), 
grouping_id(tryb, stopien, kierunek, rok) liczba
from studenci 
group by grouping sets ((tryb, stopien, kierunek, rok), (tryb, stopien, kierunek),
(tryb, rok), rok, ());

