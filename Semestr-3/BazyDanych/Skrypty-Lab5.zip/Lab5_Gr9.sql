--zad4

select l.kierunek, l.tryb, r.nr_indeksu, r.nazwisko, l.srednia
FROM (SELECT kierunek, tryb, min(srednia)srednia FROM studenci
GROUP BY kierunek, tryb)l
JOIN studenci r on
(l.kierunek = r.kierunek and l.tryb = r.tryb and l.srednia = r.srednia);

select * from studenci
where (kierunek, tryb, srednia)in
(SELECT kierunek, tryb, min(srednia)srednia FROM studenci
GROUP BY kierunek, tryb);

--zad 
select id_wlasciciela, wlasciciel, data_up,
(select count(vin) from pojazdy where typ like 'MOTOCYKL' and 
id_wlasciciela=wl.id_wlasciciela) MOt, 
(select count(vin) from pojazdy where typ like 'SAM_OSOBOWY' and 
id_wlasciciela=wl.id_wlasciciela) SO
from wlasciciele wl where data_up =
(select min(data_up) from wlasciciele 
where status_wlasciciela = wl.status_wlasciciela);
--zad 12

select id_dzialu, nazwisko, nr_akt, stanowisko, data_zatr, data_zwol
from pracownicy join dzialy using(id_dzialu) 
where (data_zwol is null or data_zwol >= Sysdate) 
and ( (id_dzialu, data_zatr) in 
(select id_dzialu,min(data_zatr) from pracownicy where
data_zwol is null or data_zwol >= Sysdate group by id_dzialu)
or (id_dzialu, data_zatr) in (select id_dzialu,max(data_zatr) 
from pracownicy where
data_zwol is null or data_zwol >= Sysdate group by id_dzialu)) order by 1;

-- zad 15
select * from 
(select to_char (czas, 'YYYY-MM-DD hh24:mi') kiedy, extract (year from czas)rok, 
id_wedkarza, nazwisko, id_gatunku, 
gatunki.nazwa gatunek, lowiska.nazwa lowisko, dlugosc from 
rejestry join gatunki using (id_gatunku) join lowiska using (id_lowiska) 
join wedkarze using (id_wedkarza))t1 join 
(select extract (year from czas)rok ,id_gatunku, avg (dlugosc)srednia from rejestry 
group by extract (year from czas) ,id_gatunku)t2 on (t1.rok=t2.rok and 
t1.id_gatunku=t2.id_gatunku and dlugosc > srednia); 

/*
select id_dzialu,min(data_zatr) from pracownicy where
data_zwol is null or data_zwol >= Sysdate group by id_dzialu;

select id_dzialu,max(data_zatr) from pracownicy where
data_zwol is null or data_zwol >= Sysdate group by id_dzialu;


select count(vin) from pojazdy where typ like 'MOTOCYKL' and id_wlasciciela=1;
*/

--zad 17
select tryb, stopien, kierunek, rok, count(*)
from studenci
group by grouping sets((tryb,stopien,kierunek,rok),(tryb,stopien,kierunek),
(tryb,stopien),(tryb),());

select tryb, stopien, kierunek, rok, count(*),
decode(GROUPING_ID(tryb, stopien, kierunek, rok), 0, 'TSKR',1,'TSK',3,'TS',7,'T',15,'ogolem')
from studenci
group by rollup(tryb,stopien,kierunek,rok);


