-- zad 1
select * from studenci where kierunek='INFORMATYKA'
and data_urodzenia=(select min(data_urodzenia) 
from studenci where kierunek='INFORMATYKA');

select * from 
(select * from studenci where kierunek='INFORMATYKA') p1 
join(select min(data_urodzenia) najstarszy
from studenci where kierunek='INFORMATYKA') p2 on(p1.data_urodzenia=najstarszy) ;


select * from studenci st where kierunek='INFORMATYKA'
and data_urodzenia=(select min(data_urodzenia) 
from studenci where kierunek='INFORMATYKA' and rok=st.rok);

-- zad 5
select * from (
select kierunek, decode(substr(imiona, -1),'a','pani','pan') plec,
max(srednia) maksymalna
from studenci group by kierunek, decode(substr(imiona, -1),'a','pani','pan')) t1 join
(select kierunek, decode(substr(imiona, -1),'a','pani','pan') plec, 
nr_indeksu, nazwisko, srednia
from studenci) t2 on
(t1.kierunek = t2.kierunek and t1.plec=t2.plec and maksymalna *0.9 <= srednia) 
Order by 1,2;

-- 


select kierunek, decode(substr(imiona, -1),'a','pani','pan') plec, 
nr_indeksu, nazwisko, srednia
from studenci where (kierunek, decode(substr(imiona, -1),'a','pani','pan'), srednia)
IN(
select kierunek, decode(substr(imiona, -1),'a','pani','pan') plec,
max(srednia) maksymalna
from studenci group by kierunek, decode(substr(imiona, -1),'a','pani','pan'));

---zad 13
select marka,typ,count(*) liczba from pojazdy group by marka,typ 
having(typ,count(*)) in  
(select typ,max(liczba) maksymalna from(
select marka,typ,count(*) liczba from pojazdy group by marka,typ) group by typ);

select marka,typ,count(*) liczba from pojazdy po group by marka,typ 
having count(*) =  
(select max(liczba) maksymalna from
( select marka,typ,count(*) liczba from pojazdy group by marka,typ) where 
typ=po.typ group by typ);

-- zad 10
select * from(
select ga.nazwa gatunek, to_char(czas,'yyyy-mm-dd hh24:mi')okres,
nazwisko, lw.nazwa lowisko, extract(day from systimestamp-czas)dni, czas,
nvl(re.id_gatunku,0)id_gatunku
from rejestry re left join gatunki ga on (re.id_gatunku=ga.id_gatunku) join
lowiska lw on (re.id_lowiska=lw.id_lowiska) join wedkarze we 
on (re.id_wedkarza=we.id_wedkarza))t1 join 
(select nvl(id_gatunku,0)id_gatunku, max(czas)ostatni from rejestry
group by nvl(id_gatunku,0))t2 on (t1.id_gatunku=t2.id_gatunku AND czas=ostatni)
order by t1.id_gatunku;

--zad 11
select nvl(t2.nazwa, 'brak polowu') nazwa, decode(t2.id_gatunku, 0, 'brak polowu',t2.id_gatunku) id_gatunku,
okres, dni, nazwisko 
from(
select ga.nazwa gatunek, to_char(czas,'yyyy-mm-dd hh24:mi')okres,
nazwisko, lw.nazwa lowisko, extract(day from systimestamp-czas)dni, czas,
nvl(re.id_gatunku,0) id_gatunku
from rejestry re full join gatunki ga on (re.id_gatunku=ga.id_gatunku) left join
lowiska lw on (re.id_lowiska=lw.id_lowiska) left join wedkarze we 
on (re.id_wedkarza=we.id_wedkarza)    )t1 
right join 
(select nvl(ga.id_gatunku,0)id_gatunku, nazwa, max(czas)ostatni from rejestry re full join gatunki ga on(re.id_gatunku=ga.id_gatunku)
group by nvl(ga.id_gatunku,0), nazwa)t2 on (t1.id_gatunku=t2.id_gatunku and czas=ostatni)
order by t1.id_gatunku;

-- zad 17
select decode( grouping (tryb),1,'razem',tryb)tryb , stopien, kierunek,rok ,count (*), grouping_id(tryb, stopien, kierunek,rok) liczba
from studenci group by rollup (tryb, stopien, kierunek,rok) ;

select decode( grouping (tryb),1,'razem',tryb)tryb , stopien, kierunek,rok ,count (*), grouping_id(tryb, stopien, kierunek,rok) liczba
from studenci group by cube(tryb, stopien, kierunek,rok) ;

select decode( grouping (tryb),1,'razem',tryb)tryb , stopien, kierunek,rok ,
count (*), grouping_id(tryb, stopien, kierunek,rok) liczba
from studenci group by grouping sets ((tryb, stopien, kierunek,rok),
(tryb, stopien,rok),(kierunek,rok),stopien,rok,()) ;






