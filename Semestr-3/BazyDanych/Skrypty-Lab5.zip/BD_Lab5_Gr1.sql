select min(data_urodzenia) from studenci where kierunek like 'INFORMATYKA';
select * from studenci where kierunek like 'INFORMATYKA' and
data_urodzenia = 
(select min(data_urodzenia) from studenci where kierunek like 'INFORMATYKA');

-- zad 4
select min(srednia) from studenci where rok=2 and stopien=1;

select * from studenci where rok=2 and stopien =1 and srednia = 
(select min(srednia) from studenci where rok=2 and stopien=1);

select * from studenci where rok=2 and stopien =1 
and (kierunek,tryb,srednia)in
(select kierunek,tryb,min(srednia) from studenci where rok=2 and stopien =1
group by kierunek,tryb);
-- optymalniej
select * from 
(select * from studenci where rok=2 and stopien =1) t1 join 
(select kierunek,tryb,min(srednia) min_srednia from studenci where rok=2
and stopien =1 group by kierunek,tryb) t2 on (t1.kierunek =t2.kierunek 
and t1.tryb = t2.tryb and srednia=min_srednia);

--zad 6/7
select w.id_wlasciciela, wlasciciel, adres, count(*)
from pojazdy p join wlasciciele w
on(p.id_wlasciciela = w.id_wlasciciela) where typ in
('SAM_OSOBOWY', 'MOTOCYKL') group by w.id_wlasciciela, wlasciciel, adres
having count(*) = (select max(count(*)) from pojazdy where typ in
('SAM_OSOBOWY', 'MOTOCYKL')
group by id_wlasciciela);

select max(count(*)) from pojazdy where typ in
('SAM_OSOBOWY', 'MOTOCYKL')
group by id_wlasciciela;


select w.id_wlasciciela, wlasciciel, adres, count(*),
(select count(*) from pojazdy where id_wlasciciela = w.id_wlasciciela
and typ = 'SAM_OSOBOWY') "LICZBA_SAM",
(select count(*) from pojazdy where id_wlasciciela = w.id_wlasciciela
and typ = 'MOTOCYKL') "LICZBA_MOTO"
from pojazdy p join wlasciciele w
on(p.id_wlasciciela = w.id_wlasciciela) where typ in
('SAM_OSOBOWY', 'MOTOCYKL') group by w.id_wlasciciela, wlasciciel, adres
having count(*) = (select max(count(*)) from pojazdy where typ in
('SAM_OSOBOWY', 'MOTOCYKL')
group by id_wlasciciela);

-- cos
select nr_indeksu, nazwisko,
(select count(*) from oceny where ocena=5 and nr_indeksu=st.nr_indeksu) Licz_5,
(select count(*) from oceny where ocena=4 and nr_indeksu=st.nr_indeksu) Licz_4,
(select count(nr_indeksu) from oceny where ocena is null and nr_indeksu=st.nr_indeksu) Brak
from studenci st;

-- zad 10
select * from
(select NVL(re.id_gatunku,0)id_gatunku, 
ga.nazwa gatunek,to_char(re.czas,'yyyy-mm-dd hh24:mi') Os, nazwisko,
lw.nazwa lowisko
from rejestry re join lowiska lw on (re.id_lowiska=lw.id_lowiska) 
left join gatunki ga on (re.id_gatunku=ga.id_gatunku)
join wedkarze we on(we.id_wedkarza=re.id_wedkarza)) t1
join
( select NVL(id_gatunku,0) id_gatunku, to_char(max(czas),'yyyy-mm-dd hh24:mi')OsP 
 from rejestry group by NVL(id_gatunku,0)) t2 on 
 (t1.id_gatunku=t2.id_gatunku and os=osp) order by 1;


t2 
on (t1.id_gatunku=t2.id_gatunku); 


select count(*) from oceny where ocena=5 and nr_indeksu=114721;
