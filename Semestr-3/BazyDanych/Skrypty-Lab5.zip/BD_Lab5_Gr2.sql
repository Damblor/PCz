--zad 1
select * from studenci;
select max(data_urodzenia) from studenci where
kierunek like 'INFORMATYKA' and imiona like '%a';

select * from studenci where 
kierunek like 'INFORMATYKA' and imiona like '%a' and
data_urodzenia = (select max(data_urodzenia) from studenci where
kierunek like 'INFORMATYKA' and imiona like '%a');

select * from (select * from studenci);

--zad 4 
select kierunek, tryb, srednia, nr_indeksu from studenci 
where (kierunek, tryb, srednia) in
(select kierunek, tryb, max(srednia) from studenci 
group by kierunek, tryb) order by 1, 2;

select * from 
(select kierunek, tryb, srednia, nr_indeksu from studenci)t1 join
(select kierunek, tryb, max(srednia) max_srednia from studenci 
group by kierunek, tryb)t2 on (t1.kierunek=t2.kierunek and t1.tryb=t2.tryb and 
max_srednia=srednia);

-- zad 12
select id_dzialu, nazwa, nr_akt, nazwisko, data_zatr from pracownicy 
join dzialy using(id_dzialu) 
where( data_zwol is null or data_zwol>= sysdate) and ((id_dzialu, data_zatr) in 
(select id_dzialu, min(data_zatr) from pracownicy 
where data_zwol is null or data_zwol>= sysdate group by id_dzialu)
or (id_dzialu, data_zatr) in 
(select id_dzialu,  max(data_zatr) from pracownicy 
where data_zwol is null or data_zwol>= sysdate group by id_dzialu));

select * from 
(select id_dzialu, nazwa, nr_akt, nazwisko, data_zatr from pracownicy 
join dzialy using(id_dzialu) 
where( data_zwol is null or data_zwol>= sysdate)) t1 JOIN
(select id_dzialu, min(data_zatr) najstarszy, max(data_zatr) najmlodszy from pracownicy 
where data_zwol is null or data_zwol>= sysdate group by id_dzialu) T2 
on (T1.id_dzialu=t2.id_dzialu and (data_zatr=najstarszy or data_zatr=najmlodszy))
order by t1.id_dzialu;
--zad 99
/* wyswietl wedkarzy ktorzy w danym roku kalendarzowym bywali czesciej na rybach 
niz  wynosi srednia przypadajaca na wedkarza
*/
select * from 
(select id_wedkarza, nazwisko, extract(year from czas) rok, count (*) liczba from
rejestry join wedkarze using (id_wedkarza)
group by id_wedkarza, nazwisko, extract(year from czas)) T1 join 
(select extract(year from czas) rok, count (*)/ count (distinct id_wedkarza)srednia 
from rejestry group by extract(year from czas)) T2 
on (T1.rok = T2.rok and liczba > srednia) order by T1.rok, id_wedkarza;

--zad 20
SELECT to_char(czas, 'DAY') dzien, lw.nazwa lowisko, ga.nazwa gatunek, 
count(re.id_gatunku), sum(waga), count(DISTINCT id_wedkarza), 
GROUPING_ID(to_char(czas, 'DAY'), lw.nazwa, ga.nazwa) numer
FROM rejestry re JOIN lowiska lw ON (re.id_lowiska=lw.id_lowiska) 
JOIN gatunki ga ON (re.id_gatunku=ga.id_gatunku)
GROUP BY ROLLUP (to_char(czas, 'DAY'), lw.nazwa, ga.nazwa);

SELECT to_char(czas, 'DAY') dzien, lw.nazwa lowisko, ga.nazwa gatunek, 
count(re.id_gatunku), sum(waga), count(DISTINCT id_wedkarza), 
GROUPING_ID(to_char(czas, 'DAY'), lw.nazwa, ga.nazwa) numer
FROM rejestry re JOIN lowiska lw ON (re.id_lowiska=lw.id_lowiska) 
JOIN gatunki ga ON (re.id_gatunku=ga.id_gatunku)
GROUP BY CUBE (to_char(czas, 'DAY'), lw.nazwa, ga.nazwa);

SELECT decode(GROUPING(to_char(czas, 'DAY')), 1, 'Podsumowanie', to_char(czas, 'DAY')) dzien, lw.nazwa lowisko, ga.nazwa gatunek, 
count(re.id_gatunku), sum(waga), count(DISTINCT id_wedkarza), 
GROUPING_ID(to_char(czas, 'DAY'), lw.nazwa, ga.nazwa) numer
FROM rejestry re JOIN lowiska lw ON (re.id_lowiska=lw.id_lowiska) 
JOIN gatunki ga ON (re.id_gatunku=ga.id_gatunku)
GROUP BY GROUPING SETS ((to_char(czas, 'DAY'), lw.nazwa, ga.nazwa), 
(to_char(czas, 'DAY'), ga.nazwa), (lw.nazwa, ga.nazwa), ga.nazwa, ());



