--zad 3
select * from lowiska;

/*select waga,nazwa,lowisko,nazwisko,imiona,dzien from
(select  id_wedkarza,id_lowiska,id_gatunku,
NVL((select nazwa from lowiska where id_lowiska=we.id_lowiska),0) lowisko,
NVL((select nazwisko from wedkarze where id_wedkarza=we.id_wedkarza),0) nazwisko,
NVL((select nazwa from gatunki where id_gatunku=we.id_gatunku),0) nazwa,
NVL((select imiona from wedkarze where id_wedkarza=we.id_wedkarza),0),

from rejestry we);

*/
select * from rejestry join wedkarze using (id_wedkarza )where trim(to_char(czas,'day')) 
in ('sobota','niedziela') and extract(month from czas)=5 and waga=(select max(waga) from rejestry where trim(to_char(czas,'day')) 
in ('sobota','niedziela') and extract(month from czas)=5);


select max(waga) from rejestry where trim(to_char(czas,'day')) 
in ('sobota','niedziela') and extract(month from czas)=5;

-- 
select nr_indeksu, nazwisko,
(select count(ocena) from oceny where ocena=5 and nr_indeksu=st.nr_indeksu) Liczba_5,
(select count(ocena) from oceny where ocena=4 and nr_indeksu=st.nr_indeksu) Liczba_4,
(select count(nr_indeksu) from oceny where ocena is null and nr_indeksu=st.nr_indeksu) Liczba_Brakow
from studenci st;

-- zad 8/9
select max(liczba) from 
(select nr_indeksu, count(ocena) liczba from oceny where ocena=5 group by nr_indeksu);

select  max(count(ocena)) liczba from oceny where ocena=5 group by nr_indeksu;

select nr_indeksu, nazwisko, kierunek, count(ocena) 
from oceny join studenci using(nr_indeksu)
where ocena = 5
group by nr_indeksu, nazwisko, kierunek having count(ocena)=
(select  max(count(ocena)) liczba from oceny where ocena=5 group by nr_indeksu)
;

select * from (select nr_indeksu, nazwisko, kierunek, count(ocena) liczba
from oceny join studenci using(nr_indeksu)
where ocena = 5 group by nr_indeksu, nazwisko, kierunek) p1 join 
(select  max(count(ocena)) max_liczba from oceny where ocena=5
group by nr_indeksu) p2 on (liczba = max_liczba) 
;
select * from 
(select ocena, max(liczba_ocen) maks from 
(select nr_indeksu,decode(ocena, null, 'brak', ocena) ocena, count(nr_indeksu) liczba_ocen
from oceny group by decode(ocena, null, 'brak', ocena), nr_indeksu)
group by ocena) p1 join 
(select nr_indeksu, nazwisko, kierunek,
decode(ocena, null, 'brak', ocena) ocena, count(nr_indeksu) liczba
from oceny join studenci using(nr_indeksu)
 group by nr_indeksu, nazwisko, kierunek, decode(ocena, null, 'brak', ocena))  p2
 on (p1.ocena=p2.ocena and maks = liczba) order by p2.ocena;
 
 --zad 17
 select decode( grouping(tryb),1,'podsumowanie',tryb)tryb, stopien, kierunek,rok,count(*),
 GROUPING_ID(tryb, stopien, kierunek,rok)nr from studenci
 group by rollup(tryb, stopien, kierunek,rok);
 
 select decode( grouping(tryb),1,'podsumowanie',tryb)tryb, stopien, kierunek,rok,count(*),
 GROUPING_ID(tryb, stopien, kierunek,rok)nr from studenci
 group by cube(tryb, stopien, kierunek,rok);
 
  select decode( grouping(tryb),1,'podsumowanie',tryb)tryb, stopien, kierunek,rok,count(*),
 GROUPING_ID(tryb, stopien, kierunek,rok)nr from studenci
 group by grouping sets((tryb, stopien, kierunek,rok),(tryb, stopien, kierunek),
 (stopien,rok),rok,());
 