-- zad 1
select * from studenci where kierunek like 'INFORMATYKA'
and srednia = (select max(srednia) from studenci where kierunek like 'INFORMATYKA');

select max(srednia) from studenci where kierunek like 'INFORMATYKA';
select * from studenci st  where kierunek like 'INFORMATYKA'
and srednia = (select max(srednia) from studenci where 
kierunek like 'INFORMATYKA' and rok=st.rok);

select nr_indeksu, nazwisko,
(select count(*) from oceny where ocena=5 and nr_indeksu=st.nr_indeksu)piatki,
(select count(*) from oceny where ocena is null and nr_indeksu=st.nr_indeksu)brak_oceny
from studenci st;

select count(*) from oceny where ocena=5 and nr_indeksu=1;
--zad 5
select kierunek, decode(substr(imiona,-1),'a','pani','pan')plec, max(srednia)
from studenci group by kierunek, decode(substr(imiona,-1),'a','pani','pan');

select * from studenci where 
(kierunek, decode(substr(imiona,-1),'a','pani','pan'),srednia) 
in(select kierunek, decode(substr(imiona,-1),'a','pani','pan')plec, max(srednia)
from studenci group by kierunek, decode(substr(imiona,-1),'a','pani','pan'));

select * from 
(select kierunek, decode(substr(imiona,-1),'a','pani','pan')plec, max(srednia)max_srednia
from studenci group by kierunek, decode(substr(imiona,-1),'a','pani','pan')) p1
join studenci st on(p1.kierunek=st.kierunek and srednia=max_srednia and
 plec = decode(substr(imiona,-1),'a','pani','pan')) where max_srednia>4.6;

--zad 10
select gatunek, czas2, dni, nazwisko, lowisko from
(select nvl(id_gatunku,0)id_gatunku, max(czas)max_czas from rejestry 
group by nvl(id_gatunku,0)) p1 join
(select nvl(re.id_gatunku,0) id_gatunku ,nvl(ga.nazwa,'brak') gatunek,
czas,to_char(czas,'yyyy-mm-dd hh24:mi')czas2, 
trunc(sysdate - trunc(czas)) dni, nazwisko,lw.nazwa lowisko
from rejestry re left join gatunki ga on(re.id_gatunku = ga.id_gatunku)
join lowiska lw on(re.id_lowiska = lw.id_lowiska) 
join wedkarze we on(re.id_wedkarza = we.id_wedkarza)) p2 
on(p1.id_gatunku = p2.id_gatunku and max_czas = p2.czas);

select gatunek, czas2, dni, nazwisko, lowisko from
(select nvl(id_gatunku,0)id_gatunku, max(czas)max_czas from rejestry 
group by nvl(id_gatunku,0)) p1 right join
(select nvl(ga.id_gatunku,0) id_gatunku ,nvl(ga.nazwa,'brak') gatunek,
czas,to_char(czas,'yyyy-mm-dd hh24:mi')czas2, 
trunc(sysdate - trunc(czas)) dni, nazwisko,lw.nazwa lowisko
from rejestry re full join gatunki ga on(re.id_gatunku = ga.id_gatunku)
left join lowiska lw on(re.id_lowiska = lw.id_lowiska) 
left join wedkarze we on(re.id_wedkarza = we.id_wedkarza)) p2 
on(p1.id_gatunku = p2.id_gatunku and max_czas = p2.czas);
--zad 20

select decode(GROUPing_ID(id_lowiska, id_gatunku), 3, 
'Ogolnie', 2, 'Po gatunku', lowiska.nazwa) lowisko,
gatunki.nazwa gatunek, count(*),
sum(waga),count(distinct id_wedkarza),
GROUPing_ID(id_lowiska, id_gatunku) ID from rejestry 
join gatunki using(id_gatunku)
join lowiska using(id_lowiska) 
group by grouping sets((lowiska.nazwa, id_lowiska, gatunki.nazwa, id_gatunku),
(lowiska.nazwa, id_lowiska ),(gatunki.nazwa, id_gatunku),());


