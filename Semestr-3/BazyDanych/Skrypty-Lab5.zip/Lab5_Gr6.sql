--zad 1
select * from studenci where kierunek='INFORMATYKA'
and data_urodzenia=(select MIN(data_urodzenia) from 
studenci where kierunek='INFORMATYKA');

select nr_indeksu, nazwisko,
(select count(*) from oceny where nr_indeksu=st.nr_indeksu and ocena=5) 
from studenci st;


select count(*) from oceny where nr_indeksu=1 and ocena=5;

--  zad 4
select kierunek, tryb, nr_indeksu,nazwisko, srednia from studenci
where rok = 2 and stopien = 1 and (kierunek,tryb,srednia) in (
select kierunek, tryb, min(srednia)
from studenci where rok = 2 and stopien = 1
group by kierunek, tryb);

select * from 
(select kierunek, tryb, nr_indeksu,nazwisko, srednia from studenci
where rok = 2 and stopien = 1) t1 join
(select kierunek, tryb, min(srednia) min_srednia
from studenci where rok = 2 and stopien = 1
group by kierunek, tryb) t2 on (t1.kierunek = t2.kierunek and 
t1.tryb = t2.tryb and t1.srednia = min_srednia);

--zad 9
--select nr_indesku,nazwisko,imiona,kierunek,rok,ocena
select nr_indeksu,nazwisko,imiona,kierunek,rok,nvl(ocena,0) ocena
, count(*) liczba
from studenci join oceny using (nr_indeksu)
group by nr_indeksu,nazwisko,imiona,kierunek,rok,ocena
having(nvl(ocena,0),count(*)) in(
select ocena,max(liczba)  from 
(select  nvl(ocena,0) ocena,nr_indeksu,count(*) liczba from oceny
group by nvl(ocena,0),nr_indeksu) group by ocena);

--zad 17
SELECT decode(grouping(tryb),1, 'razem', tryb) tryb, stopien, kierunek, rok, count(*),
GROUPING_ID(tryb, stopien, kierunek, rok)
from studenci
GROUP BY ROLLUP(tryb, stopien, kierunek, rok)
;